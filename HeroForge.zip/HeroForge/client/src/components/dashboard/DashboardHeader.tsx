import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";

const DashboardHeader: React.FC = () => {
  const { data: user, isLoading } = useQuery({
    queryKey: ["/api/auth/me"],
    staleTime: Infinity,
  });

  return (
    <div className="mb-8">
      <h1 className="text-3xl font-bold mb-2">
        Welcome Back,{" "}
        {isLoading ? (
          <Skeleton className="h-8 w-40 inline-block" />
        ) : (
          <span className="text-primary">{user?.firstName}</span>
        )}
      </h1>
      <p className="text-muted-foreground">
        "Every night is a chance to get stronger. Every day is a chance to learn." - Batman
      </p>
    </div>
  );
};

export default DashboardHeader;
