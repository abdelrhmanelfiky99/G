import React from "react";
import SideNavigation from "@/components/layouts/SideNavigation";
import TopNavBar from "@/components/layouts/TopNavBar";
import DashboardHeader from "@/components/dashboard/DashboardHeader";
import StatsOverview from "@/components/dashboard/StatsOverview";
import WeeklyActivityChart from "@/components/dashboard/WeeklyActivityChart";
import RecentAchievements from "@/components/dashboard/RecentAchievements";
import TrainingPrograms from "@/components/dashboard/TrainingPrograms";
import MentorGuidance from "@/components/dashboard/MentorGuidance";
import { useMobileNav } from "@/hooks/use-mobile-nav";

const Dashboard: React.FC = () => {
  const { isOpen, setIsOpen } = useMobileNav();

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-background">
      {/* Sidebar Navigation - Desktop */}
      <div className="hidden lg:block">
        <SideNavigation />
      </div>
      
      {/* Sidebar Navigation - Mobile */}
      {isOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setIsOpen(false)} />
          <SideNavigation isMobile onClose={() => setIsOpen(false)} />
        </div>
      )}
      
      {/* Main Content Area */}
      <main className="flex-1 overflow-x-hidden">
        {/* Top Navigation Bar */}
        <TopNavBar />
        
        {/* Dashboard Content */}
        <div className="p-6">
          {/* Dashboard Header */}
          <DashboardHeader />
          
          {/* Stats Overview */}
          <StatsOverview />
          
          {/* Weekly Activity & Recent Achievements */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            <WeeklyActivityChart className="lg:col-span-2" />
            <RecentAchievements />
          </div>
          
          {/* Training Programs & Mentor Guidance */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <TrainingPrograms />
            </div>
            <MentorGuidance />
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
