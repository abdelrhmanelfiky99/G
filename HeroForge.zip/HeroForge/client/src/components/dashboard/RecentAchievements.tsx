import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { 
  TbActivity, 
  TbRun, 
  TbBrain,
  TbMask,
  TbHeartbeat,
  TbBolt
} from "react-icons/tb";

const RecentAchievements: React.FC = () => {
  const { data: achievements, isLoading } = useQuery({
    queryKey: ["/api/user/achievements/recent"],
    staleTime: 5 * 60 * 1000, // 5 min
  });

  // Map of icon names to components
  const iconMap: Record<string, React.ReactNode> = {
    "fist-raised": <TbActivity className="text-primary badge-glow" size={22} />,
    "running": <TbRun className="text-secondary" size={22} />,
    "brain": <TbBrain className="text-primary" size={22} />,
    "mask": <TbMask className="text-primary" size={22} />,
    "heartbeat": <TbHeartbeat className="text-secondary" size={22} />,
    "bolt": <TbBolt className="text-primary" size={22} />
  };

  // Helper to format date as "2d ago" or similar
  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) {
      return "Today";
    } else if (diffDays === 1) {
      return "Yesterday";
    } else if (diffDays < 7) {
      return `${diffDays}d ago`;
    } else if (diffDays < 30) {
      return `${Math.floor(diffDays / 7)}w ago`;
    } else {
      return `${Math.floor(diffDays / 30)}mo ago`;
    }
  };

  return (
    <div className="bg-card rounded-lg p-5 shadow-lg">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-lg font-bold">Recent Achievements</h2>
        <Link href="/achievements" className="text-primary text-sm">
          View All
        </Link>
      </div>
      
      <div className="space-y-4">
        {isLoading ? (
          Array(3).fill(0).map((_, i) => (
            <Skeleton key={i} className="w-full h-20" />
          ))
        ) : achievements && achievements.length > 0 ? (
          achievements.map((achievement: any) => (
            <div key={achievement.id} className="flex items-center p-3 bg-muted rounded-lg">
              <div className="w-12 h-12 rounded-full bg-card flex items-center justify-center mr-3">
                {iconMap[achievement.achievement.iconName] || <TbActivity size={22} />}
              </div>
              <div>
                <p className="font-bold">{achievement.achievement.name}</p>
                <p className="text-xs text-muted-foreground">
                  {achievement.achievement.description}
                </p>
              </div>
              <div className="ml-auto text-xs text-muted-foreground">
                {formatTimeAgo(achievement.earnedAt)}
              </div>
            </div>
          ))
        ) : (
          <p className="text-center text-muted-foreground py-4">
            No achievements yet. Start training to earn badges!
          </p>
        )}
      </div>
      
      <Button className="w-full mt-4 bg-muted hover:bg-accent text-foreground">
        Earn More Badges
      </Button>
    </div>
  );
};

export default RecentAchievements;
