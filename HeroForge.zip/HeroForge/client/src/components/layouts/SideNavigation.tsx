import React from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  TbLayoutDashboard, 
  TbBarbell, 
  TbMedal, 
  TbUserPlus, 
  TbChartLine, 
  TbSettings 
} from "react-icons/tb";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useQuery } from "@tanstack/react-query";

type NavItemProps = {
  href: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  active?: boolean;
};

const NavItem: React.FC<NavItemProps> = ({ href, icon, children, active }) => {
  return (
    <li className="mb-1">
      <Link href={href} className={cn(
            "flex items-center px-6 py-3 text-white hover:bg-muted hover:border-l-4 hover:border-primary transition-all duration-200",
            active && "bg-muted border-l-4 border-primary"
          )}>
          <div className="w-5">{icon}</div>
          <span className="ml-3">{children}</span>
      </Link>
    </li>
  );
};

interface SideNavigationProps {
  isMobile?: boolean;
  onClose?: () => void;
}

const SideNavigation: React.FC<SideNavigationProps> = ({ isMobile, onClose }) => {
  const [location] = useLocation();
  
  const { data: user } = useQuery({
    queryKey: ["/api/auth/me"],
    staleTime: Infinity,
  });

  const navItems = [
    { href: "/", icon: <TbLayoutDashboard size={20} />, label: "Dashboard" },
    { href: "/programs", icon: <TbBarbell size={20} />, label: "Training Programs" },
    { href: "/achievements", icon: <TbMedal size={20} />, label: "Achievements" },
    { href: "/mentors", icon: <TbUserPlus size={20} />, label: "Mentors" },
    { href: "/progress", icon: <TbChartLine size={20} />, label: "Progress" },
  ];

  return (
    <aside className={cn(
      "bg-sidebar z-20",
      isMobile ? "fixed inset-0 w-64" : "lg:w-64 w-full lg:min-h-screen"
    )}>
      <div className="flex flex-col h-full">
        {/* Logo */}
        <div className="p-4 flex items-center justify-center lg:justify-start border-b border-sidebar-border">
          <div className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
              <span className="text-primary-foreground text-xl">🦇</span>
            </div>
            <h1 className="ml-3 text-xl font-bold tracking-wider text-sidebar-foreground">
              BAT<span className="text-primary">TRAIN</span>
            </h1>
          </div>
          
          {isMobile && (
            <button 
              onClick={onClose}
              className="ml-auto text-sidebar-foreground hover:text-primary"
            >
              &times;
            </button>
          )}
        </div>
        
        {/* Navigation Items */}
        <nav className="flex-1 py-4">
          <ul>
            {navItems.map((item) => (
              <NavItem 
                key={item.href}
                href={item.href}
                icon={item.icon}
                active={location === item.href}
              >
                {item.label}
              </NavItem>
            ))}
          </ul>
        </nav>
        
        {/* User Profile Section */}
        <div className="p-4 border-t border-sidebar-border">
          <div className="flex items-center">
            <Avatar className="h-10 w-10">
              <AvatarImage src={user?.profileImage} alt={user?.firstName} />
              <AvatarFallback className="bg-primary text-primary-foreground">
                {user?.firstName?.charAt(0) || "U"}
              </AvatarFallback>
            </Avatar>
            <div className="ml-3 text-sidebar-foreground">
              <p className="text-sm font-medium">
                {user?.firstName} {user?.lastName}
              </p>
              <p className="text-xs text-muted-foreground">
                {user?.role === "batman" ? "Batman" : "Robin"} Level {user?.level}
              </p>
            </div>
            <button className="ml-auto text-muted-foreground hover:text-sidebar-foreground">
              <TbSettings size={18} />
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default SideNavigation;
