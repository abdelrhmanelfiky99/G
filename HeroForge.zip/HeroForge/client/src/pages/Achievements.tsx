import React from "react";
import { useQuery } from "@tanstack/react-query";
import SideNavigation from "@/components/layouts/SideNavigation";
import TopNavBar from "@/components/layouts/TopNavBar";
import { useMobileNav } from "@/hooks/use-mobile-nav";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { TbActivity, TbRun, TbBrain, TbMask, TbHeartbeat, TbBolt, TbLock } from "react-icons/tb";

const Achievements: React.FC = () => {
  const { isOpen, setIsOpen } = useMobileNav();
  
  const { data: user } = useQuery({
    queryKey: ["/api/auth/me"],
    staleTime: Infinity,
  });
  
  const { data: userAchievements, isLoading: userAchievementsLoading } = useQuery({
    queryKey: ["/api/user/achievements"],
    staleTime: 5 * 60 * 1000, // 5 min
  });
  
  const { data: allAchievements, isLoading: allAchievementsLoading } = useQuery({
    queryKey: ["/api/achievements"],
    staleTime: 5 * 60 * 1000, // 5 min
  });
  
  // Icon mapping
  const iconMap: Record<string, React.ReactNode> = {
    "fist-raised": <TbActivity size={32} />,
    "running": <TbRun size={32} />,
    "brain": <TbBrain size={32} />,
    "mask": <TbMask size={32} />,
    "heartbeat": <TbHeartbeat size={32} />,
    "bolt": <TbBolt size={32} />
  };
  
  // Helper to check if user has an achievement
  const hasAchievement = (achievementId: number) => {
    return userAchievements?.some((ua: any) => ua.achievementId === achievementId);
  };
  
  // Group achievements by category
  const groupedAchievements: Record<string, any[]> = {};
  
  if (allAchievements) {
    allAchievements.forEach((achievement: any) => {
      if (!groupedAchievements[achievement.category]) {
        groupedAchievements[achievement.category] = [];
      }
      groupedAchievements[achievement.category].push(achievement);
    });
  }
  
  // Category titles mapping
  const categoryTitles: Record<string, string> = {
    "combat": "Combat Skills",
    "agility": "Agility & Movement",
    "intelligence": "Detective Skills"
  };

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-background">
      {/* Sidebar Navigation - Desktop */}
      <div className="hidden lg:block">
        <SideNavigation />
      </div>
      
      {/* Sidebar Navigation - Mobile */}
      {isOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setIsOpen(false)} />
          <SideNavigation isMobile onClose={() => setIsOpen(false)} />
        </div>
      )}
      
      {/* Main Content Area */}
      <main className="flex-1 overflow-x-hidden">
        {/* Top Navigation Bar */}
        <TopNavBar />
        
        {/* Page Content */}
        <div className="p-6">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Achievement Badges</h1>
            <p className="text-muted-foreground">
              Unlock badges as you progress through your training journey.
            </p>
          </div>
          
          {/* User Progress Overview */}
          <Card className="mb-8 bg-card">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                <div>
                  <h2 className="text-xl font-bold mb-1">Your Progress</h2>
                  <p className="text-muted-foreground">
                    {userAchievementsLoading ? (
                      <Skeleton className="h-5 w-40" />
                    ) : (
                      `${userAchievements?.length || 0} of ${allAchievements?.length || 0} badges earned`
                    )}
                  </p>
                </div>
                
                <div className="mt-4 md:mt-0 md:text-right">
                  <p className="text-sm text-muted-foreground mb-1">Current Level</p>
                  <p className="text-2xl font-bold text-primary">{user?.level || 1}</p>
                </div>
              </div>
              
              <Progress 
                value={userAchievementsLoading || allAchievementsLoading ? 0 : 
                  allAchievements?.length ? 
                  (userAchievements?.length / allAchievements?.length) * 100 : 0
                } 
                className="h-2 mb-2" 
              />
              
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>Robin (Beginner)</span>
                <span>Nightwing (Intermediate)</span>
                <span>Batman (Master)</span>
              </div>
            </CardContent>
          </Card>
          
          {/* Achievements by Category */}
          {allAchievementsLoading ? (
            <div className="space-y-8">
              <Skeleton className="h-60 w-full" />
              <Skeleton className="h-60 w-full" />
            </div>
          ) : (
            Object.keys(groupedAchievements).map((category) => (
              <div key={category} className="mb-8">
                <h2 className="text-xl font-bold mb-4">{categoryTitles[category] || category}</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {groupedAchievements[category].map((achievement) => {
                    const earned = hasAchievement(achievement.id);
                    const locked = user?.level < (achievement.requiredLevel || 1);
                    
                    return (
                      <Card 
                        key={achievement.id} 
                        className={`relative ${earned ? "border-primary" : locked ? "opacity-60" : ""}`}
                      >
                        <CardContent className="p-6 text-center">
                          <div 
                            className={`w-16 h-16 mx-auto rounded-full flex items-center justify-center mb-4 ${
                              earned ? "bg-primary/20 text-primary badge-glow" : 
                              locked ? "bg-muted text-muted-foreground" : "bg-secondary/20 text-secondary"
                            }`}
                          >
                            {locked ? <TbLock size={32} /> : iconMap[achievement.iconName]}
                          </div>
                          
                          <h3 className="font-bold mb-1">{achievement.name}</h3>
                          <p className="text-xs text-muted-foreground mb-3">
                            {achievement.description}
                          </p>
                          
                          {locked && (
                            <p className="text-xs bg-muted inline-block px-2 py-1 rounded">
                              Requires Level {achievement.requiredLevel}
                            </p>
                          )}
                          
                          {earned && (
                            <p className="text-xs bg-primary/20 text-primary inline-block px-2 py-1 rounded">
                              Achieved
                            </p>
                          )}
                          
                          {!earned && !locked && (
                            <p className="text-xs bg-muted inline-block px-2 py-1 rounded">
                              In Progress
                            </p>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>
            ))
          )}
        </div>
      </main>
    </div>
  );
};

export default Achievements;
