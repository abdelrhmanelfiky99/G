import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import SideNavigation from "@/components/layouts/SideNavigation";
import TopNavBar from "@/components/layouts/TopNavBar";
import { useMobileNav } from "@/hooks/use-mobile-nav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import ProgressRing from "@/components/ProgressRing";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";

const ProgressPage: React.FC = () => {
  const { isOpen, setIsOpen } = useMobileNav();
  const [timeRange, setTimeRange] = useState("month");
  
  // Mock data for charts - in real implementation this would come from API
  const mockLineData = [
    { name: "Week 1", workout: 2, skill: 20 },
    { name: "Week 2", workout: 4, skill: 30 },
    { name: "Week 3", workout: 3, skill: 40 },
    { name: "Week 4", workout: 5, skill: 50 },
    { name: "Week 5", workout: 4, skill: 60 },
    { name: "Week 6", workout: 6, skill: 70 },
  ];
  
  const mockBarData = [
    { name: "Combat", current: 65, target: 100 },
    { name: "Agility", current: 85, target: 100 },
    { name: "Strength", current: 45, target: 100 },
    { name: "Stealth", current: 70, target: 100 },
    { name: "Intelligence", current: 90, target: 100 },
  ];
  
  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ["/api/auth/me"],
    staleTime: Infinity,
  });
  
  const { data: achievements, isLoading: achievementsLoading } = useQuery({
    queryKey: ["/api/user/achievements"],
    staleTime: 5 * 60 * 1000, // 5 min
  });
  
  const { data: userPrograms, isLoading: programsLoading } = useQuery({
    queryKey: ["/api/user/programs"],
    staleTime: 5 * 60 * 1000, // 5 min
  });
  
  // Get the endpoint of the week
  const getWeeklyActivityEndpoint = () => {
    const now = new Date();
    const startDate = new Date();
    let endDate = new Date();
    
    if (timeRange === "week") {
      startDate.setDate(now.getDate() - 7);
    } else if (timeRange === "month") {
      startDate.setDate(now.getDate() - 30);
    } else if (timeRange === "year") {
      startDate.setDate(now.getDate() - 365);
    }
    
    return {
      startDate: startDate.toISOString().split('T')[0],
      endDate: endDate.toISOString().split('T')[0]
    };
  };
  
  const { startDate, endDate } = getWeeklyActivityEndpoint();
  
  const { data: activities, isLoading: activitiesLoading } = useQuery({
    queryKey: ["/api/user/activity", startDate, endDate],
    queryFn: async () => {
      const res = await fetch(`/api/user/activity?startDate=${startDate}&endDate=${endDate}`);
      if (!res.ok) throw new Error("Failed to fetch activities");
      return res.json();
    },
    staleTime: 5 * 60 * 1000, // 5 min
  });
  
  // Calculate progress statistics
  const calculateStats = () => {
    if (!activities || !userPrograms) {
      return {
        totalWorkouts: 0,
        avgIntensity: "N/A",
        avgDuration: "0 min",
        programProgress: 0
      };
    }
    
    const totalWorkouts = activities.length;
    
    // Calculate average intensity
    const intensityMap: { [key: string]: number } = { low: 1, medium: 2, high: 3 };
    const intensitySum = activities.reduce(
      (sum: number, act: any) => sum + intensityMap[act.intensity || "medium"], 
      0
    );
    const avgIntensityValue = totalWorkouts ? intensitySum / totalWorkouts : 0;
    let avgIntensity = "Low";
    if (avgIntensityValue > 2.3) avgIntensity = "High";
    else if (avgIntensityValue > 1.7) avgIntensity = "Medium";
    
    // Calculate average duration
    const totalMinutes = activities.reduce((sum: number, act: any) => sum + (act.minutes || 0), 0);
    const avgDuration = totalWorkouts ? `${Math.round(totalMinutes / totalWorkouts)} min` : "0 min";
    
    // Calculate overall program progress
    const programProgress = userPrograms.reduce(
      (sum: number, prog: any) => sum + prog.progress, 
      0
    ) / (userPrograms.length || 1);
    
    return { totalWorkouts, avgIntensity, avgDuration, programProgress };
  };
  
  const stats = calculateStats();

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-background">
      {/* Sidebar Navigation - Desktop */}
      <div className="hidden lg:block">
        <SideNavigation />
      </div>
      
      {/* Sidebar Navigation - Mobile */}
      {isOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setIsOpen(false)} />
          <SideNavigation isMobile onClose={() => setIsOpen(false)} />
        </div>
      )}
      
      {/* Main Content Area */}
      <main className="flex-1 overflow-x-hidden">
        {/* Top Navigation Bar */}
        <TopNavBar />
        
        {/* Page Content */}
        <div className="p-6">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Progress Tracking</h1>
            <p className="text-muted-foreground">
              Monitor your training journey and skill development over time.
            </p>
          </div>
          
          {/* Progress Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {/* Total Workouts */}
            <Card className="bg-card">
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <h3 className="text-muted-foreground text-sm mb-1">Total Workouts</h3>
                  {activitiesLoading ? (
                    <Skeleton className="h-16 w-16 rounded-full" />
                  ) : (
                    <div className="text-4xl font-bold mb-1">{stats.totalWorkouts}</div>
                  )}
                  <p className="text-xs text-muted-foreground">
                    {timeRange === "week" ? "This week" : timeRange === "month" ? "This month" : "This year"}
                  </p>
                </div>
              </CardContent>
            </Card>
            
            {/* Average Intensity */}
            <Card className="bg-card">
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <h3 className="text-muted-foreground text-sm mb-1">Average Intensity</h3>
                  {activitiesLoading ? (
                    <Skeleton className="h-16 w-16 rounded-full" />
                  ) : (
                    <div className="text-4xl font-bold mb-1">{stats.avgIntensity}</div>
                  )}
                  <p className="text-xs text-muted-foreground">
                    Based on your recent workouts
                  </p>
                </div>
              </CardContent>
            </Card>
            
            {/* Average Duration */}
            <Card className="bg-card">
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <h3 className="text-muted-foreground text-sm mb-1">Average Duration</h3>
                  {activitiesLoading ? (
                    <Skeleton className="h-16 w-16 rounded-full" />
                  ) : (
                    <div className="text-4xl font-bold mb-1">{stats.avgDuration}</div>
                  )}
                  <p className="text-xs text-muted-foreground">
                    Per workout session
                  </p>
                </div>
              </CardContent>
            </Card>
            
            {/* Overall Progress */}
            <Card className="bg-card">
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <h3 className="text-muted-foreground text-sm mb-1">Program Progress</h3>
                  {programsLoading ? (
                    <Skeleton className="h-16 w-16 rounded-full" />
                  ) : (
                    <ProgressRing 
                      progress={Math.round(stats.programProgress)} 
                      size={64} 
                      strokeWidth={4} 
                      className="text-primary my-1"
                    />
                  )}
                  <p className="text-xs text-muted-foreground">
                    Average across all programs
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Progress Charts */}
          <div className="mb-8">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Progress Charts</h2>
              <Select 
                defaultValue="month"
                onValueChange={(value) => setTimeRange(value)}
              >
                <SelectTrigger className="w-[150px] h-9">
                  <SelectValue placeholder="Select timeframe" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="week">Last 7 days</SelectItem>
                  <SelectItem value="month">Last 30 days</SelectItem>
                  <SelectItem value="year">Last 365 days</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <Tabs defaultValue="progress">
              <TabsList>
                <TabsTrigger value="progress">Workout Progression</TabsTrigger>
                <TabsTrigger value="skills">Skill Development</TabsTrigger>
              </TabsList>
              
              <TabsContent value="progress" className="mt-4">
                <Card className="bg-card">
                  <CardHeader>
                    <CardTitle>Workout Frequency & Skill Level</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart
                          data={mockLineData}
                          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                          <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" />
                          <YAxis yAxisId="left" stroke="hsl(var(--muted-foreground))" />
                          <YAxis yAxisId="right" orientation="right" stroke="hsl(var(--muted-foreground))" />
                          <Tooltip 
                            contentStyle={{ 
                              backgroundColor: "hsl(var(--card))", 
                              borderColor: "hsl(var(--border))",
                              color: "hsl(var(--foreground))"
                            }} 
                          />
                          <Legend />
                          <Line 
                            yAxisId="left"
                            type="monotone" 
                            dataKey="workout" 
                            name="Workouts Completed" 
                            stroke="hsl(var(--primary))" 
                            activeDot={{ r: 8 }} 
                          />
                          <Line 
                            yAxisId="right"
                            type="monotone" 
                            dataKey="skill" 
                            name="Skill Points" 
                            stroke="hsl(var(--secondary))" 
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="skills" className="mt-4">
                <Card className="bg-card">
                  <CardHeader>
                    <CardTitle>Skill Category Progress</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={mockBarData}
                          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                          <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" />
                          <YAxis stroke="hsl(var(--muted-foreground))" />
                          <Tooltip 
                            contentStyle={{ 
                              backgroundColor: "hsl(var(--card))", 
                              borderColor: "hsl(var(--border))",
                              color: "hsl(var(--foreground))"
                            }} 
                          />
                          <Legend />
                          <Bar dataKey="current" name="Current Level" fill="hsl(var(--primary))" />
                          <Bar dataKey="target" name="Target Level" fill="hsl(var(--secondary))" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
          
          {/* Level Progress */}
          <div className="mb-8">
            <h2 className="text-xl font-bold mb-4">Level Progression</h2>
            <Card className="bg-card">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-lg font-bold">Current Level</h3>
                      {userLoading ? (
                        <Skeleton className="h-6 w-8" />
                      ) : (
                        <span className="text-lg text-primary font-bold">{user?.level}</span>
                      )}
                    </div>
                    <p className="text-muted-foreground text-sm">
                      {userLoading ? (
                        <Skeleton className="h-4 w-40 mt-1" />
                      ) : (
                        `${user?.experience || 0} / ${(user?.level || 1) * 100} XP to next level`
                      )}
                    </p>
                  </div>
                  
                  <div className="mt-4 md:mt-0">
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground text-sm">Robin</span>
                      <Progress 
                        value={user?.level ? (user.level / 10) * 100 : 0} 
                        className="h-2 w-40" 
                      />
                      <span className="text-muted-foreground text-sm">Batman</span>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-1">
                      <h4 className="font-medium">Combat Skills</h4>
                      <span>65/100</span>
                    </div>
                    <Progress value={65} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <h4 className="font-medium">Agility & Movement</h4>
                      <span>85/100</span>
                    </div>
                    <Progress value={85} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <h4 className="font-medium">Stealth Techniques</h4>
                      <span>70/100</span>
                    </div>
                    <Progress value={70} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <h4 className="font-medium">Detective Skills</h4>
                      <span>90/100</span>
                    </div>
                    <Progress value={90} className="h-2" />
                  </div>
                </div>
                
                <div className="flex justify-between items-center mt-6 pt-6 border-t border-muted">
                  <div>
                    <h4 className="font-medium">Next Achievement</h4>
                    <p className="text-muted-foreground text-sm">Master Combatant - Level 5</p>
                  </div>
                  <Button>View All Skills</Button>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Achievement Progress */}
          <div>
            <h2 className="text-xl font-bold mb-4">Achievement Progress</h2>
            <Card className="bg-card">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <h3 className="font-bold">Achievements Earned</h3>
                    <p className="text-muted-foreground text-sm">
                      {achievementsLoading ? (
                        <Skeleton className="h-4 w-40 mt-1" />
                      ) : (
                        `${achievements?.length || 0} badges unlocked`
                      )}
                    </p>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button variant="outline">View All</Button>
                    <Button>Earn More</Button>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 bg-muted rounded-lg text-center">
                    <h4 className="font-medium mb-2">Combat</h4>
                    <div className="flex justify-center mb-2">
                      <ProgressRing 
                        progress={60} 
                        size={80} 
                        strokeWidth={6} 
                        className="text-primary" 
                      />
                    </div>
                    <p className="text-sm text-muted-foreground">3/5 achievements</p>
                  </div>
                  
                  <div className="p-4 bg-muted rounded-lg text-center">
                    <h4 className="font-medium mb-2">Agility</h4>
                    <div className="flex justify-center mb-2">
                      <ProgressRing 
                        progress={80} 
                        size={80} 
                        strokeWidth={6} 
                        className="text-secondary" 
                      />
                    </div>
                    <p className="text-sm text-muted-foreground">4/5 achievements</p>
                  </div>
                  
                  <div className="p-4 bg-muted rounded-lg text-center">
                    <h4 className="font-medium mb-2">Intelligence</h4>
                    <div className="flex justify-center mb-2">
                      <ProgressRing 
                        progress={40} 
                        size={80} 
                        strokeWidth={6} 
                        className="text-accent-foreground" 
                      />
                    </div>
                    <p className="text-sm text-muted-foreground">2/5 achievements</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ProgressPage;
