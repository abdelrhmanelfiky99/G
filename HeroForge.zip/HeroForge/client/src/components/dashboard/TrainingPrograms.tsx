import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { TbClock, TbArrowsSort } from "react-icons/tb";
import { cn } from "@/lib/utils";

const ProgramCard: React.FC<{
  program: any;
  className?: string;
}> = ({ program, className }) => {
  return (
    <div className={cn("bg-card rounded-lg overflow-hidden shadow-lg", className)}>
      <div
        className="h-40 bg-cover bg-center"
        style={{ backgroundImage: `url(${program.program.imageUrl})` }}
      />
      <div className="p-4">
        <div className="flex justify-between items-center mb-2">
          <h3 className="font-bold">{program.program.title}</h3>
          {program.progress >= 100 ? (
            <span className="bg-green-500 text-white text-xs font-bold px-2 py-1 rounded">
              COMPLETED
            </span>
          ) : program.progress > 0 ? (
            <span className="bg-primary text-primary-foreground text-xs font-bold px-2 py-1 rounded">
              {program.progress}% DONE
            </span>
          ) : (
            <span className="bg-secondary text-secondary-foreground text-xs font-bold px-2 py-1 rounded">
              NEW
            </span>
          )}
        </div>
        <p className="text-sm text-muted-foreground mb-3">
          {program.program.description}
        </p>
        <Progress 
          value={program.progress} 
          className="h-1.5 mb-3" 
        />
        <div className="flex text-sm">
          <div className="flex items-center mr-4">
            <TbClock className="mr-1 text-muted-foreground" />
            <span>{program.program.duration}</span>
          </div>
          <div className="flex items-center">
            <TbArrowsSort className="mr-1 text-muted-foreground" />
            <span className="capitalize">{program.program.difficulty}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

const TrainingPrograms: React.FC = () => {
  const { data: userPrograms, isLoading } = useQuery({
    queryKey: ["/api/user/programs"],
    staleTime: 5 * 60 * 1000, // 5 min
  });

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-bold">Your Training Programs</h2>
        <Link href="/programs" className="text-primary text-sm">
          View All
        </Link>
      </div>
      
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Skeleton className="w-full h-64" />
          <Skeleton className="w-full h-64" />
        </div>
      ) : userPrograms && userPrograms.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {userPrograms.slice(0, 2).map((program: any) => (
            <ProgramCard key={program.id} program={program} />
          ))}
        </div>
      ) : (
        <div className="bg-card rounded-lg p-6 text-center">
          <p className="mb-4 text-muted-foreground">
            You haven't joined any training programs yet.
          </p>
          <Link href="/programs" className="inline-block bg-primary text-primary-foreground font-bold py-2 px-4 rounded">
            Browse Programs
          </Link>
        </div>
      )}
    </div>
  );
};

export default TrainingPrograms;
