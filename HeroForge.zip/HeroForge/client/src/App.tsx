import { Switch, Route, useLocation } from "wouter";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import TrainingPrograms from "@/pages/TrainingPrograms";
import Achievements from "@/pages/Achievements";
import Mentors from "@/pages/Mentors";
import Progress from "@/pages/Progress";
import Login from "@/pages/Login";

// Protected route component
function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const [_, setLocation] = useLocation();
  
  const { data: user, isLoading } = useQuery({
    queryKey: ["/api/auth/me"],
    staleTime: Infinity,
  });
  
  useEffect(() => {
    if (!isLoading && !user) {
      setLocation("/login");
    }
  }, [isLoading, user, setLocation]);
  
  // Show nothing while checking authentication
  if (isLoading) return null;
  
  // If authenticated, show the component
  return user ? <Component /> : null;
}

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/">
        {() => <ProtectedRoute component={Dashboard} />}
      </Route>
      <Route path="/programs">
        {() => <ProtectedRoute component={TrainingPrograms} />}
      </Route>
      <Route path="/achievements">
        {() => <ProtectedRoute component={Achievements} />}
      </Route>
      <Route path="/mentors">
        {() => <ProtectedRoute component={Mentors} />}
      </Route>
      <Route path="/progress">
        {() => <ProtectedRoute component={Progress} />}
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <TooltipProvider>
      <Router />
    </TooltipProvider>
  );
}

export default App;
