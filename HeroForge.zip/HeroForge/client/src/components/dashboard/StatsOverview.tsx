import React from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  TbClock, 
  TbMedal
} from "react-icons/tb";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import ProgressRing from "@/components/ProgressRing";

const StatsOverview: React.FC = () => {
  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ["/api/auth/me"],
    staleTime: Infinity,
  });

  const { data: userPrograms, isLoading: programsLoading } = useQuery({
    queryKey: ["/api/user/programs"],
    staleTime: 5 * 60 * 1000, // 5 min
  });

  const { data: achievements, isLoading: achievementsLoading } = useQuery({
    queryKey: ["/api/user/achievements"],
    staleTime: 5 * 60 * 1000, // 5 min
  });

  // Calculate weekly workout progress (completed / total)
  const totalWorkouts = 4; // This could come from API
  const completedWorkouts = 3; // This could come from API
  const workoutProgress = Math.round((completedWorkouts / totalWorkouts) * 100);

  // Next session data (mock data, would come from API)
  const nextSession = {
    name: "Combat Basics",
    time: "Today, 6:00 PM",
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {/* Stat Card: Weekly Progress */}
      <div className="bg-card rounded-lg p-5 shadow-lg flex items-center">
        <div className="mr-4 relative">
          {programsLoading ? (
            <Skeleton className="w-16 h-16 rounded-full" />
          ) : (
            <ProgressRing 
              progress={workoutProgress} 
              size={64} 
              strokeWidth={5} 
              className="text-primary"
            />
          )}
        </div>
        <div>
          <p className="text-muted-foreground text-sm">Weekly Progress</p>
          {programsLoading ? (
            <div className="font-bold text-lg">
              <Skeleton className="h-6 w-24" />
            </div>
          ) : (
            <p className="font-bold text-lg">
              {`${completedWorkouts}/${totalWorkouts} Workouts`}
            </p>
          )}
        </div>
      </div>
      
      {/* Stat Card: Skill Level */}
      <div className="bg-card rounded-lg p-5 shadow-lg">
        <div className="flex justify-between mb-2">
          <p className="text-muted-foreground text-sm">Skill Level</p>
          {userLoading ? (
            <Skeleton className="h-5 w-16" />
          ) : (
            <p className="text-sm font-bold text-primary">Level {user?.level}</p>
          )}
        </div>
        
        <Progress 
          value={user?.level ? (user.level / 10) * 100 : 0} 
          className="h-2 mb-2" 
        />
        
        <div className="flex justify-between text-xs">
          <span>Robin</span>
          <span>Nightwing</span>
          <span>Batman</span>
        </div>
      </div>
      
      {/* Stat Card: Badges Earned */}
      <div className="bg-card rounded-lg p-5 shadow-lg">
        <div className="flex items-center">
          <div className="mr-4 text-secondary text-3xl">
            <TbMedal />
          </div>
          <div>
            <p className="text-muted-foreground text-sm">Badges Earned</p>
            {achievementsLoading ? (
              <Skeleton className="h-6 w-24 my-1" />
            ) : (
              <>
                <p className="font-bold text-lg">{achievements?.length || 0} badges</p>
                <p className="text-xs text-muted-foreground">2 new this week</p>
              </>
            )}
          </div>
        </div>
      </div>
      
      {/* Stat Card: Next Session */}
      <div className="bg-secondary rounded-lg p-5 shadow-lg">
        <p className="text-gray-200 text-sm mb-1">Next Training Session</p>
        <p className="font-bold text-lg mb-3">{nextSession.name}</p>
        <div className="flex items-center text-sm">
          <TbClock className="mr-2" />
          <span>{nextSession.time}</span>
        </div>
        <button className="mt-3 bg-white text-secondary text-sm font-bold py-1 px-3 rounded">
          Start Session
        </button>
      </div>
    </div>
  );
};

export default StatsOverview;
