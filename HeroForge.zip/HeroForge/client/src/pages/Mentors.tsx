import React from "react";
import { useQuery } from "@tanstack/react-query";
import SideNavigation from "@/components/layouts/SideNavigation";
import TopNavBar from "@/components/layouts/TopNavBar";
import { useMobileNav } from "@/hooks/use-mobile-nav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { TbMessageCircle } from "react-icons/tb";

const Mentors: React.FC = () => {
  const { isOpen, setIsOpen } = useMobileNav();
  
  const { data: mentorData, isLoading } = useQuery({
    queryKey: ["/api/user/mentor"],
    staleTime: 5 * 60 * 1000, // 5 min
  });

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-background">
      {/* Sidebar Navigation - Desktop */}
      <div className="hidden lg:block">
        <SideNavigation />
      </div>
      
      {/* Sidebar Navigation - Mobile */}
      {isOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setIsOpen(false)} />
          <SideNavigation isMobile onClose={() => setIsOpen(false)} />
        </div>
      )}
      
      {/* Main Content Area */}
      <main className="flex-1 overflow-x-hidden">
        {/* Top Navigation Bar */}
        <TopNavBar />
        
        {/* Page Content */}
        <div className="p-6">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Mentorship</h1>
            <p className="text-muted-foreground">
              Learn from Batman-level experts who will guide your journey.
            </p>
          </div>
          
          <Tabs defaultValue="current" className="mb-8">
            <TabsList>
              <TabsTrigger value="current">Your Mentor</TabsTrigger>
              <TabsTrigger value="guidance">Mentor Guidance</TabsTrigger>
            </TabsList>
            
            <TabsContent value="current" className="mt-6">
              {isLoading ? (
                <Skeleton className="h-80 w-full" />
              ) : mentorData ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card className="bg-card shadow-lg">
                    <CardHeader className="pb-0">
                      <CardTitle>Your Batman</CardTitle>
                    </CardHeader>
                    <CardContent className="pt-6">
                      <div className="flex flex-col items-center text-center mb-6">
                        <Avatar className="w-32 h-32 mb-4">
                          <AvatarImage 
                            src={mentorData.mentor.profileImage} 
                            alt={mentorData.mentor.firstName}
                          />
                          <AvatarFallback className="bg-primary text-primary-foreground text-4xl">
                            {mentorData.mentor.firstName.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <h2 className="text-2xl font-bold">
                          {mentorData.mentor.firstName} {mentorData.mentor.lastName}
                        </h2>
                        <p className="text-muted-foreground">
                          Level {mentorData.mentor.level} Batman
                        </p>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 mb-6">
                        <div className="bg-muted p-4 rounded-lg text-center">
                          <p className="text-sm text-muted-foreground">Mentoring Since</p>
                          <p className="font-bold">
                            {new Date(mentorData.mentorship.startedAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="bg-muted p-4 rounded-lg text-center">
                          <p className="text-sm text-muted-foreground">Status</p>
                          <p className="font-bold capitalize">{mentorData.mentorship.status}</p>
                        </div>
                      </div>
                      
                      <div className="flex justify-center">
                        <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                          <TbMessageCircle className="mr-2" />
                          Message Your Mentor
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-card shadow-lg">
                    <CardHeader className="pb-0">
                      <CardTitle>Mentor's Philosophy</CardTitle>
                    </CardHeader>
                    <CardContent className="pt-6">
                      <div className="prose dark:prose-invert text-foreground mb-6">
                        <blockquote className="italic border-l-4 border-primary pl-4 py-1">
                          "It's not who I am underneath, but what I do that defines me."
                        </blockquote>
                        
                        <p>
                          As your mentor, I will help you develop not just physical strength,
                          but the mental fortitude and analytical skills that make up a complete
                          warrior. Training is about pushing your limits and overcoming fear.
                        </p>
                        
                        <p>
                          My teaching method emphasizes practical application. Theory is important,
                          but you must learn by doing. Expect to be challenged, but know that I'll
                          never ask you to do something you're truly not capable of.
                        </p>
                      </div>
                      
                      <div className="bg-muted p-4 rounded-lg mb-4">
                        <h3 className="font-bold mb-1">Specialties</h3>
                        <div className="flex flex-wrap gap-2">
                          <span className="bg-primary/20 text-primary text-xs px-2 py-1 rounded">Combat</span>
                          <span className="bg-secondary/20 text-secondary text-xs px-2 py-1 rounded">Strategy</span>
                          <span className="bg-muted-foreground/20 text-xs px-2 py-1 rounded">Investigation</span>
                          <span className="bg-muted-foreground/20 text-xs px-2 py-1 rounded">Stealth</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ) : (
                <Card className="bg-card shadow-lg">
                  <CardContent className="p-8 text-center">
                    <h2 className="text-2xl font-bold mb-4">No Mentor Assigned Yet</h2>
                    <p className="text-muted-foreground mb-6">
                      Having a mentor can significantly accelerate your training progress. Mentors provide
                      personalized guidance, advanced techniques, and accountability.
                    </p>
                    <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                      Request a Mentor
                    </Button>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
            
            <TabsContent value="guidance" className="mt-6">
              {isLoading ? (
                <Skeleton className="h-80 w-full" />
              ) : mentorData && mentorData.guidance ? (
                <Card className="bg-card shadow-lg">
                  <CardHeader>
                    <CardTitle>Current Training Focus</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-card border border-border rounded-lg p-6 mb-6">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-lg font-bold">{mentorData.guidance.focus}</h3>
                          <p className="text-muted-foreground text-sm">
                            Assigned on {new Date(mentorData.guidance.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className={`text-xs px-2 py-1 rounded-full ${
                          mentorData.guidance.priority === 'high' ? 'bg-primary text-primary-foreground' :
                          mentorData.guidance.priority === 'medium' ? 'bg-amber-500 text-black' : 'bg-muted text-muted-foreground'
                        }`}>
                          {mentorData.guidance.priority.charAt(0).toUpperCase() + mentorData.guidance.priority.slice(1)} Priority
                        </div>
                      </div>
                      
                      <blockquote className="italic border-l-4 border-primary pl-4 py-2 mb-4">
                        "{mentorData.guidance.message}"
                      </blockquote>
                      
                      <div className="flex justify-end">
                        <Button variant="outline" className="mr-2">Mark as Reviewed</Button>
                        <Button>Begin Training</Button>
                      </div>
                    </div>
                    
                    <div className="bg-muted rounded-lg p-6">
                      <h3 className="font-bold mb-4">Training History</h3>
                      <ul className="space-y-2">
                        <li className="flex justify-between items-center p-2 border-b border-muted-foreground/10">
                          <span>Combat stance fundamentals</span>
                          <span className="text-muted-foreground text-sm">2 weeks ago</span>
                        </li>
                        <li className="flex justify-between items-center p-2 border-b border-muted-foreground/10">
                          <span>Stealth movement basics</span>
                          <span className="text-muted-foreground text-sm">3 weeks ago</span>
                        </li>
                        <li className="flex justify-between items-center p-2">
                          <span>Endurance training protocol</span>
                          <span className="text-muted-foreground text-sm">1 month ago</span>
                        </li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <Card className="bg-card shadow-lg">
                  <CardContent className="p-8 text-center">
                    <h2 className="text-2xl font-bold mb-4">No Mentor Guidance Available</h2>
                    <p className="text-muted-foreground mb-6">
                      You don't have any mentor guidance yet. Get a mentor to receive personalized
                      training advice and guidance.
                    </p>
                    <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                      Get a Mentor
                    </Button>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
};

export default Mentors;
