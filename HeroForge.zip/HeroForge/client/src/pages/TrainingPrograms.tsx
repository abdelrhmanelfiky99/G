import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import SideNavigation from "@/components/layouts/SideNavigation";
import TopNavBar from "@/components/layouts/TopNavBar";
import { useMobileNav } from "@/hooks/use-mobile-nav";
import { Button } from "@/components/ui/button";
import { TbClock, TbArrowsSort, TbPlus, TbTarget, TbStar, TbTrophy } from "react-icons/tb";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogClose
} from "@/components/ui/dialog";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const TrainingPrograms: React.FC = () => {
  const { isOpen, setIsOpen } = useMobileNav();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [enrollingProgramId, setEnrollingProgramId] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<string>("my-programs");
  const [selectedProgramId, setSelectedProgramId] = useState<number | null>(null);
  const [showProgramDetails, setShowProgramDetails] = useState<boolean>(false);
  
  const { data: userPrograms, isLoading: userProgramsLoading } = useQuery({
    queryKey: ["/api/user/programs"],
    staleTime: 5 * 60 * 1000, // 5 min
  });
  
  const { data: allPrograms, isLoading: allProgramsLoading } = useQuery({
    queryKey: ["/api/programs"],
    staleTime: 5 * 60 * 1000, // 5 min
  });
  
  // Helper to check if a program is already assigned to the user
  const isProgramAssigned = (programId: number) => {
    return userPrograms?.some((up: any) => up.programId === programId);
  };
  
  // Switch to my programs tab after successful enrollment
  const switchToMyPrograms = () => {
    setActiveTab("my-programs");
  };
  
  // Enrollment mutation
  const enrollMutation = useMutation({
    mutationFn: async (programId: number) => {
      const response = await apiRequest("POST", "/api/user/programs", {
        programId,
        progress: 0,
        isCompleted: false,
        startedAt: new Date().toISOString()
      });
      return await response.json();
    },
    onMutate: (programId) => {
      setEnrollingProgramId(programId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/programs"] });
      toast({
        title: "Enrolled Successfully",
        description: "You have been enrolled in the program. Start your training now!",
      });
      setEnrollingProgramId(null);
      // Switch to my programs tab after successful enrollment
      switchToMyPrograms();
    },
    onError: (error: Error) => {
      toast({
        title: "Enrollment Failed",
        description: error.message || "Failed to enroll in the program. Please try again.",
        variant: "destructive",
      });
      setEnrollingProgramId(null);
    }
  });

  // Query for program exercises
  const { data: programExercises, isLoading: exercisesLoading } = useQuery({
    queryKey: ["/api/programs", selectedProgramId, "exercises"],
    queryFn: async () => {
      if (!selectedProgramId) return [];
      const response = await fetch(`/api/programs/${selectedProgramId}/exercises`);
      return await response.json();
    },
    enabled: !!selectedProgramId && showProgramDetails,
  });

  // Get the current user program from the list
  const currentUserProgram = userPrograms?.find((p: any) => p.programId === selectedProgramId);
  
  // Get the current program from the all programs list
  const currentProgram = allPrograms?.find((p: any) => p.id === selectedProgramId);
  
  // Update progress handler
  const updateProgressMutation = useMutation({
    mutationFn: async (data: { programId: number, progress: number, isCompleted?: boolean }) => {
      const userProgram = userPrograms?.find((p: any) => p.programId === data.programId);
      if (!userProgram) return null;
      
      const response = await apiRequest("PATCH", `/api/user/programs/${userProgram.id}/progress`, {
        progress: data.progress,
        isCompleted: data.isCompleted
      });
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/programs"] });
      toast({
        title: "Progress Updated",
        description: "Your training progress has been updated.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update progress. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Handle completion of an exercise
  const handleCompleteExercise = (exerciseId: number) => {
    if (!currentUserProgram) return;
    
    // Calculate new progress (simple implementation: each exercise is worth equal percentage)
    const exerciseCount = programExercises?.length || 1;
    const exerciseValue = 100 / exerciseCount;
    const newProgress = Math.min(100, currentUserProgram.progress + exerciseValue);
    const isCompleted = newProgress >= 100;
    
    updateProgressMutation.mutate({
      programId: currentUserProgram.programId,
      progress: Math.round(newProgress),
      isCompleted
    });
  };

  return (
    <div className="flex flex-col lg:flex-row min-h-screen bg-background">
      {/* Sidebar Navigation - Desktop */}
      <div className="hidden lg:block">
        <SideNavigation />
      </div>
      
      {/* Sidebar Navigation - Mobile */}
      {isOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setIsOpen(false)} />
          <SideNavigation isMobile onClose={() => setIsOpen(false)} />
        </div>
      )}
      
      {/* Program Details Dialog */}
      <Dialog open={showProgramDetails} onOpenChange={setShowProgramDetails}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          {exercisesLoading ? (
            <div className="flex justify-center p-8">
              <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
            </div>
          ) : (
            <>
              <DialogHeader>
                <div className="flex items-center justify-between">
                  <DialogTitle className="text-2xl">{currentProgram?.title}</DialogTitle>
                  {currentUserProgram && (
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground">Progress:</span>
                      <span className="text-sm font-medium">{currentUserProgram.progress}%</span>
                    </div>
                  )}
                </div>
                <DialogDescription className="mt-2">
                  {currentProgram?.description}
                </DialogDescription>
              </DialogHeader>
              
              <div className="mt-6">
                <div className="flex justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <TbTarget className="text-primary" />
                    <span className="font-medium">Training Exercises</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs px-2 py-1 rounded-full bg-secondary text-secondary-foreground">
                      {currentProgram?.difficulty}
                    </span>
                    <span className="text-xs px-2 py-1 rounded-full bg-muted text-muted-foreground">
                      {currentProgram?.duration}
                    </span>
                  </div>
                </div>
                
                <Accordion type="single" collapsible className="w-full">
                  {programExercises?.map((exercise: any, index: number) => (
                    <AccordionItem key={exercise.id} value={exercise.id.toString()}>
                      <AccordionTrigger className="hover:no-underline">
                        <div className="flex items-center gap-3 text-left">
                          <div className="flex items-center justify-center h-8 w-8 rounded-full bg-muted text-muted-foreground">
                            {index + 1}
                          </div>
                          <div>
                            <h4 className="text-base font-medium">{exercise.name}</h4>
                            <span className="text-xs text-muted-foreground capitalize">
                              {exercise.type} · {exercise.difficulty}
                            </span>
                          </div>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="pl-11 pr-2">
                          <p className="text-sm text-muted-foreground mb-4">
                            {exercise.description}
                          </p>
                          <div className="p-4 rounded-md bg-card border mb-4">
                            <h5 className="text-sm font-medium mb-2">Instructions:</h5>
                            <div className="text-sm whitespace-pre-line text-muted-foreground">
                              {exercise.instructions}
                            </div>
                          </div>
                          
                          {exercise.videoId && (
                            <div className="mb-4">
                              <h5 className="text-sm font-medium mb-2">Video Demonstration:</h5>
                              <div className="relative aspect-video rounded-lg overflow-hidden">
                                <iframe
                                  src={`https://www.youtube.com/embed/${exercise.videoId}`}
                                  title={`${exercise.name} demonstration`}
                                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                  allowFullScreen
                                  className="absolute top-0 left-0 w-full h-full"
                                ></iframe>
                              </div>
                            </div>
                          )}
                          
                          <Button 
                            className="w-full"
                            onClick={() => handleCompleteExercise(exercise.id)}
                            disabled={updateProgressMutation.isPending}
                          >
                            {updateProgressMutation.isPending ? "Updating..." : "Mark as Completed"}
                          </Button>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>
            </>
          )}
          
          <div className="flex justify-end mt-4">
            <DialogClose asChild>
              <Button variant="outline">Close</Button>
            </DialogClose>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Main Content Area */}
      <main className="flex-1 overflow-x-hidden">
        {/* Top Navigation Bar */}
        <TopNavBar />
        
        {/* Page Content */}
        <div className="p-6">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Training Programs</h1>
            <p className="text-muted-foreground">
              Master your skills with training programs designed by Gotham's finest.
            </p>
          </div>
          
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-8">
            <TabsList>
              <TabsTrigger value="my-programs">My Programs</TabsTrigger>
              <TabsTrigger value="all-programs">Available Programs</TabsTrigger>
            </TabsList>
            
            <TabsContent value="my-programs" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {userProgramsLoading ? (
                  Array(3).fill(0).map((_, i) => (
                    <Skeleton key={i} className="h-80 w-full" />
                  ))
                ) : userPrograms?.length > 0 ? (
                  userPrograms.map((program: any) => (
                    <Card key={program.id} className="overflow-hidden">
                      <div
                        className="h-40 bg-cover bg-center"
                        style={{ backgroundImage: `url(${program.program.imageUrl})` }}
                      />
                      <CardHeader className="p-4 pb-0">
                        <div className="flex justify-between items-center">
                          <CardTitle>{program.program.title}</CardTitle>
                          {program.progress >= 100 ? (
                            <span className="text-xs bg-green-500 text-white px-2 py-1 rounded-full">
                              Completed
                            </span>
                          ) : (
                            <span className="text-xs bg-primary text-primary-foreground px-2 py-1 rounded-full">
                              {program.progress}%
                            </span>
                          )}
                        </div>
                      </CardHeader>
                      <CardContent className="p-4">
                        <p className="text-sm text-muted-foreground mb-4">
                          {program.program.description}
                        </p>
                        <Progress value={program.progress} className="h-1.5 mb-4" />
                        <div className="flex justify-between mb-4 text-sm">
                          <div className="flex items-center">
                            <TbClock className="mr-1 text-muted-foreground" />
                            <span>{program.program.duration}</span>
                          </div>
                          <div className="flex items-center">
                            <TbArrowsSort className="mr-1 text-muted-foreground" />
                            <span className="capitalize">{program.program.difficulty}</span>
                          </div>
                        </div>
                        <Button 
                          className="w-full"
                          onClick={() => {
                            setSelectedProgramId(program.programId);
                            setShowProgramDetails(true);
                          }}
                        >
                          {program.progress > 0 ? "Continue Training" : "Start Program"}
                        </Button>
                      </CardContent>
                    </Card>
                  ))
                ) : (
                  <div className="col-span-3 text-center py-12">
                    <p className="text-muted-foreground mb-4">You haven't joined any programs yet.</p>
                    <Button onClick={() => setActiveTab("all-programs")}>
                      Browse Available Programs
                    </Button>
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="all-programs" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {allProgramsLoading ? (
                  Array(3).fill(0).map((_, i) => (
                    <Skeleton key={i} className="h-80 w-full" />
                  ))
                ) : allPrograms?.length > 0 ? (
                  allPrograms.map((program: any) => {
                    const isAssigned = isProgramAssigned(program.id);
                    
                    return (
                      <Card key={program.id} className="overflow-hidden">
                        <div
                          className="h-40 bg-cover bg-center"
                          style={{ backgroundImage: `url(${program.imageUrl})` }}
                        />
                        <CardHeader className="p-4 pb-0">
                          <div className="flex justify-between items-center">
                            <CardTitle>{program.title}</CardTitle>
                            {isAssigned ? (
                              <span className="text-xs bg-muted text-muted-foreground px-2 py-1 rounded-full">
                                Enrolled
                              </span>
                            ) : program.difficulty === "advanced" ? (
                              <span className="text-xs bg-secondary text-secondary-foreground px-2 py-1 rounded-full">
                                Advanced
                              </span>
                            ) : (
                              <span className="text-xs bg-primary text-primary-foreground px-2 py-1 rounded-full">
                                {program.difficulty}
                              </span>
                            )}
                          </div>
                        </CardHeader>
                        <CardContent className="p-4">
                          <p className="text-sm text-muted-foreground mb-4">
                            {program.description}
                          </p>
                          <div className="flex justify-between mb-4 text-sm">
                            <div className="flex items-center">
                              <TbClock className="mr-1 text-muted-foreground" />
                              <span>{program.duration}</span>
                            </div>
                            <div className="flex items-center">
                              <TbArrowsSort className="mr-1 text-muted-foreground" />
                              <span className="capitalize">{program.difficulty}</span>
                            </div>
                          </div>
                          <Button 
                            className="w-full" 
                            variant={isAssigned ? "outline" : "default"}
                            disabled={isAssigned || enrollingProgramId === program.id}
                            onClick={() => enrollMutation.mutate(program.id)}
                          >
                            {isAssigned 
                              ? "Already Enrolled" 
                              : enrollingProgramId === program.id
                                ? "Enrolling..." 
                                : "Enroll in Program"
                            }
                          </Button>
                        </CardContent>
                      </Card>
                    );
                  })
                ) : (
                  <div className="col-span-3 text-center py-12">
                    <p className="text-muted-foreground">No programs available at the moment.</p>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
};

export default TrainingPrograms;
