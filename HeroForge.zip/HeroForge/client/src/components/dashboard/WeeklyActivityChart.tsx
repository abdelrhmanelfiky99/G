import React, { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

type WeeklyActivityProps = {
  className?: string;
};

const WeeklyActivityChart: React.FC<WeeklyActivityProps> = ({ className }) => {
  const [chartLoaded, setChartLoaded] = useState(false);
  const [dateRange, setDateRange] = useState("thisWeek");
  
  // Get this week's start and end dates
  const getThisWeekDates = () => {
    const now = new Date();
    const dayOfWeek = now.getDay(); // 0-6 (Sunday-Saturday)
    const startDate = new Date(now);
    startDate.setDate(now.getDate() - dayOfWeek);
    startDate.setHours(0, 0, 0, 0);
    
    const endDate = new Date(startDate);
    endDate.setDate(startDate.getDate() + 6);
    endDate.setHours(23, 59, 59, 999);
    
    return { startDate, endDate };
  };
  
  // Get last week's start and end dates
  const getLastWeekDates = () => {
    const { startDate, endDate } = getThisWeekDates();
    startDate.setDate(startDate.getDate() - 7);
    endDate.setDate(endDate.getDate() - 7);
    return { startDate, endDate };
  };
  
  // Get dates based on selected range
  const getDatesForRange = () => {
    switch (dateRange) {
      case "lastWeek":
        return getLastWeekDates();
      case "lastMonth":
        // Simplified for demo purposes
        const { startDate } = getThisWeekDates();
        startDate.setDate(startDate.getDate() - 30);
        return { startDate, endDate: new Date() };
      default:
        return getThisWeekDates();
    }
  };
  
  const { startDate, endDate } = getDatesForRange();
  
  // Format dates for query params
  const startDateStr = startDate.toISOString().split('T')[0];
  const endDateStr = endDate.toISOString().split('T')[0];
  
  const { data: activities, isLoading } = useQuery({
    queryKey: ["/api/user/activity", startDateStr, endDateStr],
    queryFn: async () => {
      const res = await fetch(`/api/user/activity?startDate=${startDateStr}&endDate=${endDateStr}`);
      if (!res.ok) throw new Error("Failed to fetch activities");
      return res.json();
    },
    staleTime: 5 * 60 * 1000, // 5 min
  });
  
  const dayNames = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  
  // Process activity data for chart
  const processActivityData = () => {
    if (!activities || activities.length === 0) {
      return dayNames.map(() => ({ value: 0, isActive: false }));
    }
    
    // Group activities by day and calculate total minutes
    const dailyMinutes: { [key: string]: number } = {};
    const today = new Date().getDay(); // 0 = Sunday, 1 = Monday, ...
    
    activities.forEach((activity: any) => {
      const date = new Date(activity.date);
      const dayIndex = date.getDay(); // 0-6
      const dayKey = dayIndex === 0 ? 6 : dayIndex - 1; // Convert to 0-6 (Mon-Sun)
      
      if (!dailyMinutes[dayKey]) {
        dailyMinutes[dayKey] = 0;
      }
      
      dailyMinutes[dayKey] += activity.minutes;
    });
    
    // Find the max value to normalize heights
    const maxMinutes = Math.max(...Object.values(dailyMinutes), 30); // Min 30 mins for scale
    
    // Create chart data
    return dayNames.map((_, index) => {
      const minutes = dailyMinutes[index] || 0;
      const value = minutes ? (minutes / maxMinutes) * 100 : 0;
      
      // Convert to same 0-6 scale as dayIndex
      const todayIndex = today === 0 ? 6 : today - 1;
      const isActive = index === todayIndex;
      
      return { value, isActive };
    });
  };
  
  const chartData = processActivityData();
  
  useEffect(() => {
    // Animate chart bars on load
    const timer = setTimeout(() => {
      setChartLoaded(true);
    }, 300);
    
    return () => clearTimeout(timer);
  }, [activities]);
  
  // Calculate activity stats
  const calculateStats = () => {
    if (!activities || activities.length === 0) {
      return { totalTime: "0h 0m", avgIntensity: "N/A", bestDay: "N/A" };
    }
    
    // Total time
    const totalMinutes = activities.reduce((sum: number, act: any) => sum + act.minutes, 0);
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    const totalTime = `${hours}h ${minutes}m`;
    
    // Avg intensity
    const intensityMap: { [key: string]: number } = { low: 1, medium: 2, high: 3 };
    const intensitySum = activities.reduce(
      (sum: number, act: any) => sum + intensityMap[act.intensity], 
      0
    );
    const avgIntensityValue = intensitySum / activities.length;
    let avgIntensity = "Low";
    if (avgIntensityValue > 2.3) avgIntensity = "High";
    else if (avgIntensityValue > 1.7) avgIntensity = "Medium";
    
    // Best day - day with most minutes
    const dailyMinutes: { [key: string]: number } = {};
    activities.forEach((activity: any) => {
      const date = new Date(activity.date);
      const dayIndex = date.getDay();
      const dayKey = dayIndex === 0 ? 6 : dayIndex - 1;
      
      if (!dailyMinutes[dayKey]) {
        dailyMinutes[dayKey] = 0;
      }
      
      dailyMinutes[dayKey] += activity.minutes;
    });
    
    let bestDayIndex = 0;
    let maxMinutes = 0;
    
    Object.entries(dailyMinutes).forEach(([dayIndex, minutes]) => {
      if (minutes > maxMinutes) {
        maxMinutes = minutes;
        bestDayIndex = parseInt(dayIndex);
      }
    });
    
    const bestDay = dayNames[bestDayIndex];
    
    return { totalTime, avgIntensity, bestDay };
  };
  
  const stats = calculateStats();

  return (
    <div className={cn("bg-card rounded-lg p-5 shadow-lg", className)}>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-lg font-bold">Weekly Activity</h2>
        <Select 
          defaultValue="thisWeek"
          onValueChange={(value) => setDateRange(value)}
        >
          <SelectTrigger className="w-[140px] h-8 bg-muted">
            <SelectValue placeholder="This Week" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="thisWeek">This Week</SelectItem>
            <SelectItem value="lastWeek">Last Week</SelectItem>
            <SelectItem value="lastMonth">Last Month</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      {isLoading ? (
        <Skeleton className="w-full h-40 mb-2" />
      ) : (
        <div className="flex items-end h-40 space-x-4 mb-2">
          {chartData.map((data, index) => (
            <div key={index} className="flex flex-col items-center flex-1">
              <div 
                className={cn(
                  "w-full rounded-t-md chart-bar transition-all duration-500", 
                  data.isActive ? "bg-primary" : "bg-muted",
                )}
                style={{ height: chartLoaded ? `${data.value}%` : "0%" }}
              />
            </div>
          ))}
        </div>
      )}
      
      <div className="flex text-xs text-muted-foreground justify-between">
        {dayNames.map((day, index) => (
          <div 
            key={index} 
            className={cn(
              "text-center", 
              chartData[index].isActive && "text-primary font-bold"
            )}
          >
            {day}
          </div>
        ))}
      </div>
      
      <div className="mt-4 pt-4 border-t border-muted flex justify-between text-sm">
        <div>
          <p className="text-muted-foreground">Total Time</p>
          <p className="font-bold">{stats.totalTime}</p>
        </div>
        <div>
          <p className="text-muted-foreground">Avg. Intensity</p>
          <p className="font-bold">{stats.avgIntensity}</p>
        </div>
        <div>
          <p className="text-muted-foreground">Best Day</p>
          <p className="font-bold text-primary">{stats.bestDay}</p>
        </div>
      </div>
    </div>
  );
};

export default WeeklyActivityChart;
