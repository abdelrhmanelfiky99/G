import { db } from "./db";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { eq, and, desc, lte, gte } from "drizzle-orm";
import { pool } from "./db";
import {
  User,
  InsertUser,
  Program,
  InsertProgram,
  Exercise,
  InsertExercise,
  ProgramExercise,
  InsertProgramExercise,
  UserProgram,
  InsertUserProgram,
  Achievement,
  InsertAchievement,
  UserAchievement,
  InsertUserAchievement,
  Mentorship,
  InsertMentorship,
  MentorGuidance,
  InsertMentorGuidance,
  WeeklyActivity,
  InsertWeeklyActivity,
  users,
  programs,
  exercises,
  programExercises,
  userPrograms,
  achievements,
  userAchievements,
  mentorships,
  mentorGuidance,
  weeklyActivity
} from "@shared/schema";
import { IStorage } from "./storage";

const PostgresSessionStore = connectPg(session);

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
    });
    
    // Initialize with sample data if needed
    this.initializeData();
  }
  
  private async initializeData(): Promise<void> {
    // Check if we have any users
    const existingUsers = await db.select().from(users).limit(1);
    
    if (existingUsers.length > 0) {
      console.log("Database already has data, skipping initialization");
      return;
    }
    
    console.log("Initializing database with sample data");
    
    // Create batman user (mentor)
    const batman: InsertUser = {
      username: "batman",
      password: "password",
      firstName: "Bruce",
      lastName: "Wayne",
      email: "bruce@wayne.com",
      profileImage: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5",
      role: "batman",
      level: 10,
      experience: 10000
    };
    
    const batmanUser = await this.createUser(batman);
    
    // Create sample robin user
    const robin: InsertUser = {
      username: "robin",
      password: "password",
      firstName: "Dick",
      lastName: "Grayson",
      email: "dick@wayne.com",
      profileImage: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5",
      role: "robin",
      level: 3,
      experience: 1500
    };
    
    const robinUser = await this.createUser(robin);
    
    // Create mentorship
    await this.createMentorship({
      mentorId: batmanUser.id,
      menteeId: robinUser.id,
      status: "active"
    });
    
    // Create achievements
    const combatBasicsAchievement = await this.createAchievement({
      name: "Combat Basics",
      description: "Completed 5 basic combat sessions",
      iconName: "fist-raised",
      category: "combat",
      requiredLevel: 1
    });
    
    const agilityMasterAchievement = await this.createAchievement({
      name: "Agility Master",
      description: "Completed all agility exercises",
      iconName: "running",
      category: "agility",
      requiredLevel: 2
    });
    
    const detectiveSkillsAchievement = await this.createAchievement({
      name: "Detective Skills",
      description: "Solved 3 training cases",
      iconName: "brain",
      category: "intelligence",
      requiredLevel: 3
    });
    
    // Award achievements to robin
    await this.awardAchievementToUser({
      userId: robinUser.id,
      achievementId: combatBasicsAchievement.id
    });
    
    await this.awardAchievementToUser({
      userId: robinUser.id,
      achievementId: agilityMasterAchievement.id
    });
    
    await this.awardAchievementToUser({
      userId: robinUser.id,
      achievementId: detectiveSkillsAchievement.id
    });
    
    // Create training programs
    const combatProgram = await this.createProgram({
      title: "Combat Training",
      description: "Basic fighting techniques and self-defense",
      imageUrl: "https://images.unsplash.com/photo-1549060279-7e168fcee0c2",
      duration: "8 weeks",
      difficulty: "intermediate",
      createdById: batmanUser.id
    });
    
    const stealthProgram = await this.createProgram({
      title: "Stealth & Agility",
      description: "Move silently and improve reaction time",
      imageUrl: "https://images.unsplash.com/photo-1599058917212-d750089bc07e",
      duration: "6 weeks",
      difficulty: "beginner",
      createdById: batmanUser.id
    });
    
    // Assign programs to robin
    await this.assignProgramToUser({
      userId: robinUser.id,
      programId: combatProgram.id,
      progress: 75,
      isCompleted: false
    });
    
    await this.assignProgramToUser({
      userId: robinUser.id,
      programId: stealthProgram.id,
      progress: 10,
      isCompleted: false
    });
    
    // Add mentor guidance
    const mentorship = await this.getMentorshipByMenteeId(robinUser.id);
    if (mentorship) {
      await this.createMentorGuidance({
        mentorshipId: mentorship.id,
        message: "Remember, it's not just about physical strength, but mental discipline. Focus on your technique this week.",
        focus: "Combat stance and basic strikes",
        priority: "high"
      });
    }
    
    // Add weekly activity data for Robin
    const now = new Date();
    const daysOfWeek = 7;
    const activities = [30, 60, 40, 85, 65, 20, 50]; // percentages of daily activity
    
    for (let i = 0; i < daysOfWeek; i++) {
      const date = new Date(now);
      date.setDate(date.getDate() - (daysOfWeek - 1) + i);
      
      await this.recordActivity({
        userId: robinUser.id,
        date,
        minutes: Math.floor(activities[i] * 1.2), // Convert percentage to minutes
        intensity: i === 3 ? "high" : "medium", // Thursday (index 3) is high intensity
        programId: i % 2 === 0 ? combatProgram.id : stealthProgram.id
      });
    }
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [createdUser] = await db.insert(users).values(user).returning();
    return createdUser;
  }

  async updateUserLevel(id: number, level: number, experience: number): Promise<User> {
    const [updatedUser] = await db
      .update(users)
      .set({ level, experience })
      .where(eq(users.id, id))
      .returning();
    
    if (!updatedUser) {
      throw new Error(`User with id ${id} not found`);
    }
    
    return updatedUser;
  }

  // Program methods
  async createProgram(program: InsertProgram): Promise<Program> {
    const [createdProgram] = await db.insert(programs).values(program).returning();
    return createdProgram;
  }

  async getAllPrograms(): Promise<Program[]> {
    return await db.select().from(programs);
  }

  async getProgramById(id: number): Promise<Program | undefined> {
    const [program] = await db.select().from(programs).where(eq(programs.id, id));
    return program;
  }

  async getProgramsByMentorId(mentorId: number): Promise<Program[]> {
    return await db
      .select()
      .from(programs)
      .where(eq(programs.createdById, mentorId));
  }

  // Exercise methods
  async createExercise(exercise: InsertExercise): Promise<Exercise> {
    const [createdExercise] = await db.insert(exercises).values(exercise).returning();
    return createdExercise;
  }

  async getAllExercises(): Promise<Exercise[]> {
    return await db.select().from(exercises);
  }

  // Program Exercise methods
  async addExerciseToProgram(programExercise: InsertProgramExercise): Promise<ProgramExercise> {
    const [createdProgramExercise] = await db.insert(programExercises).values(programExercise).returning();
    return createdProgramExercise;
  }

  async getExercisesByProgramId(programId: number): Promise<Exercise[]> {
    const result = await db
      .select({
        exercise: exercises,
      })
      .from(programExercises)
      .innerJoin(exercises, eq(exercises.id, programExercises.exerciseId))
      .where(eq(programExercises.programId, programId))
      .orderBy(programExercises.order);
    
    return result.map(r => r.exercise);
  }

  // User Program methods
  async assignProgramToUser(userProgram: InsertUserProgram): Promise<UserProgram> {
    const now = new Date();
    const [createdUserProgram] = await db
      .insert(userPrograms)
      .values({
        ...userProgram,
        startedAt: now,
        completedAt: null,
      })
      .returning();
    
    return createdUserProgram;
  }

  async getUserPrograms(userId: number): Promise<(UserProgram & { program: Program })[]> {
    const result = await db
      .select({
        userProgram: userPrograms,
        program: programs,
      })
      .from(userPrograms)
      .innerJoin(programs, eq(programs.id, userPrograms.programId))
      .where(eq(userPrograms.userId, userId));
    
    return result.map(r => ({
      ...r.userProgram,
      program: r.program,
    }));
  }

  async updateUserProgramProgress(id: number, progress: number, isCompleted: boolean = false): Promise<UserProgram> {
    const now = new Date();
    const [updatedUserProgram] = await db
      .update(userPrograms)
      .set({
        progress,
        isCompleted,
        completedAt: isCompleted ? now : null,
      })
      .where(eq(userPrograms.id, id))
      .returning();
    
    if (!updatedUserProgram) {
      throw new Error(`UserProgram with id ${id} not found`);
    }
    
    return updatedUserProgram;
  }

  // Achievement methods
  async createAchievement(achievement: InsertAchievement): Promise<Achievement> {
    const [createdAchievement] = await db.insert(achievements).values(achievement).returning();
    return createdAchievement;
  }

  async getAllAchievements(): Promise<Achievement[]> {
    return await db.select().from(achievements);
  }

  async getAchievementById(id: number): Promise<Achievement | undefined> {
    const [achievement] = await db.select().from(achievements).where(eq(achievements.id, id));
    return achievement;
  }

  // User Achievement methods
  async awardAchievementToUser(userAchievement: InsertUserAchievement): Promise<UserAchievement> {
    const now = new Date();
    const [createdUserAchievement] = await db
      .insert(userAchievements)
      .values({
        ...userAchievement,
        earnedAt: now,
      })
      .returning();
    
    return createdUserAchievement;
  }

  async getUserAchievements(userId: number): Promise<(UserAchievement & { achievement: Achievement })[]> {
    const result = await db
      .select({
        userAchievement: userAchievements,
        achievement: achievements,
      })
      .from(userAchievements)
      .innerJoin(achievements, eq(achievements.id, userAchievements.achievementId))
      .where(eq(userAchievements.userId, userId));
    
    return result.map(r => ({
      ...r.userAchievement,
      achievement: r.achievement,
    }));
  }

  async getRecentUserAchievements(userId: number, limit: number): Promise<(UserAchievement & { achievement: Achievement })[]> {
    const result = await db
      .select({
        userAchievement: userAchievements,
        achievement: achievements,
      })
      .from(userAchievements)
      .innerJoin(achievements, eq(achievements.id, userAchievements.achievementId))
      .where(eq(userAchievements.userId, userId))
      .orderBy(desc(userAchievements.earnedAt))
      .limit(limit);
    
    return result.map(r => ({
      ...r.userAchievement,
      achievement: r.achievement,
    }));
  }

  // Mentorship methods
  async createMentorship(mentorship: InsertMentorship): Promise<Mentorship> {
    const now = new Date();
    const [createdMentorship] = await db
      .insert(mentorships)
      .values({
        ...mentorship,
        startedAt: now,
      })
      .returning();
    
    return createdMentorship;
  }

  async getMentorshipByMenteeId(menteeId: number): Promise<(Mentorship & { mentor: User }) | undefined> {
    const result = await db
      .select({
        mentorship: mentorships,
        mentor: users,
      })
      .from(mentorships)
      .innerJoin(users, eq(users.id, mentorships.mentorId))
      .where(
        and(
          eq(mentorships.menteeId, menteeId),
          eq(mentorships.status, "active")
        )
      );
    
    if (result.length === 0) {
      return undefined;
    }
    
    return {
      ...result[0].mentorship,
      mentor: result[0].mentor,
    };
  }

  // Mentor Guidance methods
  async createMentorGuidance(guidance: InsertMentorGuidance): Promise<MentorGuidance> {
    const now = new Date();
    const [createdGuidance] = await db
      .insert(mentorGuidance)
      .values({
        ...guidance,
        createdAt: now,
      })
      .returning();
    
    return createdGuidance;
  }

  async getLatestMentorGuidance(mentorshipId: number): Promise<MentorGuidance | undefined> {
    const [guidance] = await db
      .select()
      .from(mentorGuidance)
      .where(eq(mentorGuidance.mentorshipId, mentorshipId))
      .orderBy(desc(mentorGuidance.createdAt))
      .limit(1);
    
    return guidance;
  }

  // Weekly Activity methods
  async recordActivity(activity: InsertWeeklyActivity): Promise<WeeklyActivity> {
    const [createdActivity] = await db.insert(weeklyActivity).values(activity).returning();
    return createdActivity;
  }

  async getWeeklyActivity(userId: number, startDate: Date, endDate: Date): Promise<WeeklyActivity[]> {
    return await db
      .select()
      .from(weeklyActivity)
      .where(
        and(
          eq(weeklyActivity.userId, userId),
          gte(weeklyActivity.date, startDate),
          lte(weeklyActivity.date, endDate)
        )
      )
      .orderBy(weeklyActivity.date);
  }
}