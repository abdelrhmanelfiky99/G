import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User and profiles
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull().unique(),
  level: integer("level").notNull().default(1),
  experience: integer("experience").notNull().default(0),
  profileImage: text("profile_image"),
  role: text("role").notNull().default("robin"), // robin or batman (mentor)
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  firstName: true,
  lastName: true,
  email: true,
  profileImage: true,
  level: true,
  experience: true,
  role: true,
});

// Training programs
export const programs = pgTable("programs", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url"),
  duration: text("duration").notNull(), // e.g. "8 weeks"
  difficulty: text("difficulty").notNull(), // beginner, intermediate, advanced
  createdById: integer("created_by_id").notNull(), // mentor/batman who created it
});

export const insertProgramSchema = createInsertSchema(programs).pick({
  title: true,
  description: true,
  imageUrl: true,
  duration: true,
  difficulty: true,
  createdById: true,
});

// Exercises
export const exercises = pgTable("exercises", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(), // e.g., strength, agility, combat, etc.
  difficulty: text("difficulty").notNull(),
  instructions: text("instructions").notNull(),
  imageUrl: text("image_url"),
  videoId: text("video_id"), // YouTube video ID for demonstrations
});

export const insertExerciseSchema = createInsertSchema(exercises).pick({
  name: true,
  description: true,
  type: true,
  difficulty: true,
  instructions: true,
  imageUrl: true,
  videoId: true,
});

// Program Exercises (Join table)
export const programExercises = pgTable("program_exercises", {
  id: serial("id").primaryKey(),
  programId: integer("program_id").notNull(),
  exerciseId: integer("exercise_id").notNull(),
  order: integer("order").notNull(),
});

export const insertProgramExerciseSchema = createInsertSchema(programExercises).pick({
  programId: true,
  exerciseId: true,
  order: true,
});

// User Program Progress
export const userPrograms = pgTable("user_programs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  programId: integer("program_id").notNull(),
  progress: integer("progress").notNull().default(0), // 0-100 percentage
  isCompleted: boolean("is_completed").notNull().default(false),
  startedAt: timestamp("started_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const insertUserProgramSchema = createInsertSchema(userPrograms).pick({
  userId: true,
  programId: true,
  progress: true,
  isCompleted: true,
});

// Achievements/Badges
export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  iconName: text("icon_name").notNull(), // FontAwesome icon name
  category: text("category").notNull(), // e.g., combat, agility, intelligence
  requiredLevel: integer("required_level"),
});

export const insertAchievementSchema = createInsertSchema(achievements).pick({
  name: true,
  description: true,
  iconName: true,
  category: true,
  requiredLevel: true,
});

// User Achievements
export const userAchievements = pgTable("user_achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  achievementId: integer("achievement_id").notNull(),
  earnedAt: timestamp("earned_at").notNull().defaultNow(),
});

export const insertUserAchievementSchema = createInsertSchema(userAchievements).pick({
  userId: true,
  achievementId: true,
});

// Mentorship relationships
export const mentorships = pgTable("mentorships", {
  id: serial("id").primaryKey(),
  mentorId: integer("mentor_id").notNull(), // Batman
  menteeId: integer("mentee_id").notNull(), // Robin
  startedAt: timestamp("started_at").notNull().defaultNow(),
  status: text("status").notNull().default("active"), // active, completed, paused
});

export const insertMentorshipSchema = createInsertSchema(mentorships).pick({
  mentorId: true,
  menteeId: true,
  status: true,
});

// Mentor advice/guidance
export const mentorGuidance = pgTable("mentor_guidance", {
  id: serial("id").primaryKey(),
  mentorshipId: integer("mentorship_id").notNull(),
  message: text("message").notNull(),
  focus: text("focus"),
  priority: text("priority").default("medium"), // low, medium, high
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertMentorGuidanceSchema = createInsertSchema(mentorGuidance).pick({
  mentorshipId: true,
  message: true,
  focus: true,
  priority: true,
});

// Weekly Activity
export const weeklyActivity = pgTable("weekly_activity", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: timestamp("date").notNull(),
  minutes: integer("minutes").notNull().default(0),
  intensity: text("intensity").notNull().default("medium"), // low, medium, high
  programId: integer("program_id"),
});

export const insertWeeklyActivitySchema = createInsertSchema(weeklyActivity).pick({
  userId: true,
  date: true,
  minutes: true,
  intensity: true,
  programId: true,
});

// Types export
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Program = typeof programs.$inferSelect;
export type InsertProgram = z.infer<typeof insertProgramSchema>;

export type Exercise = typeof exercises.$inferSelect;
export type InsertExercise = z.infer<typeof insertExerciseSchema>;

export type ProgramExercise = typeof programExercises.$inferSelect;
export type InsertProgramExercise = z.infer<typeof insertProgramExerciseSchema>;

export type UserProgram = typeof userPrograms.$inferSelect;
export type InsertUserProgram = z.infer<typeof insertUserProgramSchema>;

export type Achievement = typeof achievements.$inferSelect;
export type InsertAchievement = z.infer<typeof insertAchievementSchema>;

export type UserAchievement = typeof userAchievements.$inferSelect;
export type InsertUserAchievement = z.infer<typeof insertUserAchievementSchema>;

export type Mentorship = typeof mentorships.$inferSelect;
export type InsertMentorship = z.infer<typeof insertMentorshipSchema>;

export type MentorGuidance = typeof mentorGuidance.$inferSelect;
export type InsertMentorGuidance = z.infer<typeof insertMentorGuidanceSchema>;

export type WeeklyActivity = typeof weeklyActivity.$inferSelect;
export type InsertWeeklyActivity = z.infer<typeof insertWeeklyActivitySchema>;
