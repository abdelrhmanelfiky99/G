import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";

const MentorGuidance: React.FC = () => {
  const { data: mentorData, isLoading } = useQuery({
    queryKey: ["/api/user/mentor"],
    staleTime: 5 * 60 * 1000, // 5 min
  });

  return (
    <div>
      <div className="mb-4">
        <h2 className="text-lg font-bold">Your Mentor</h2>
      </div>
      
      {isLoading ? (
        <div className="bg-card rounded-lg p-5 shadow-lg">
          <div className="flex items-center mb-4">
            <Skeleton className="w-16 h-16 rounded-full mr-4" />
            <div>
              <Skeleton className="h-6 w-32 mb-2" />
              <Skeleton className="h-4 w-24" />
            </div>
          </div>
          <Skeleton className="h-20 w-full mb-4" />
          <Skeleton className="h-24 w-full mb-4" />
          <Skeleton className="h-10 w-full" />
        </div>
      ) : mentorData ? (
        <div className="bg-card rounded-lg p-5 shadow-lg">
          <div className="flex items-center mb-4">
            <Avatar className="w-16 h-16 mr-4">
              <AvatarImage 
                src={mentorData.mentor.profileImage} 
                alt={mentorData.mentor.firstName}
              />
              <AvatarFallback className="bg-primary text-primary-foreground">
                {mentorData.mentor.firstName.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-bold">
                {mentorData.mentor.firstName} {mentorData.mentor.lastName}
              </h3>
              <p className="text-sm text-muted-foreground">
                Your Batman - Level {mentorData.mentor.level}
              </p>
            </div>
          </div>
          
          {mentorData.guidance && (
            <>
              <p className="text-sm mb-4 italic border-l-2 border-primary pl-3">
                "{mentorData.guidance.message}"
              </p>
              
              {mentorData.guidance.focus && (
                <div className="bg-muted p-3 rounded-lg mb-4">
                  <div className="flex justify-between items-center mb-2">
                    <h4 className="font-bold text-sm">Today's Focus</h4>
                    <span className={`text-xs ${
                      mentorData.guidance.priority === 'high' ? 'text-primary' :
                      mentorData.guidance.priority === 'medium' ? 'text-amber-500' : 'text-muted-foreground'
                    }`}>
                      {mentorData.guidance.priority.charAt(0).toUpperCase() + mentorData.guidance.priority.slice(1)} Priority
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground">{mentorData.guidance.focus}</p>
                </div>
              )}
            </>
          )}
          
          <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
            Message Your Mentor
          </Button>
        </div>
      ) : (
        <div className="bg-card rounded-lg p-5 shadow-lg">
          <div className="text-center py-6">
            <p className="mb-4 text-muted-foreground">
              You don't have a mentor yet. Having a mentor can accelerate your training!
            </p>
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
              Find a Mentor
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default MentorGuidance;
