import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import express from "express";
import { z } from "zod";
import {
  insertUserSchema,
  insertUserProgramSchema,
  insertWeeklyActivitySchema,
  insertMentorGuidanceSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  const apiRouter = express.Router();
  app.use("/api", apiRouter);

  // Auth endpoints
  apiRouter.post("/auth/login", async (req, res) => {
    const { username, password } = req.body;
    
    if (!username || !password) {
      return res.status(400).json({ message: "Username and password required" });
    }
    
    const user = await storage.getUserByUsername(username);
    
    if (!user || user.password !== password) {
      return res.status(401).json({ message: "Invalid credentials" });
    }
    
    // Set user in session
    req.session.userId = user.id;
    
    // Don't return password
    const { password: _, ...userWithoutPassword } = user;
    
    res.json(userWithoutPassword);
  });

  apiRouter.post("/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }
      
      const user = await storage.createUser(userData);
      
      // Set user in session
      req.session.userId = user.id;
      
      // Don't return password
      const { password: _, ...userWithoutPassword } = user;
      
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  apiRouter.get("/auth/me", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const user = await storage.getUser(userId);
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Don't return password
    const { password: _, ...userWithoutPassword } = user;
    
    res.json(userWithoutPassword);
  });

  apiRouter.post("/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Error logging out" });
      }
      
      res.json({ message: "Logged out successfully" });
    });
  });

  // User programs
  apiRouter.get("/programs", async (req, res) => {
    const programs = await storage.getAllPrograms();
    res.json(programs);
  });

  apiRouter.get("/programs/:id", async (req, res) => {
    const programId = parseInt(req.params.id);
    
    if (isNaN(programId)) {
      return res.status(400).json({ message: "Invalid program ID" });
    }
    
    const program = await storage.getProgramById(programId);
    
    if (!program) {
      return res.status(404).json({ message: "Program not found" });
    }
    
    res.json(program);
  });
  
  apiRouter.get("/programs/:id/exercises", async (req, res) => {
    const programId = parseInt(req.params.id);
    
    if (isNaN(programId)) {
      return res.status(400).json({ message: "Invalid program ID" });
    }
    
    const exercises = await storage.getExercisesByProgramId(programId);
    
    if (!exercises || exercises.length === 0) {
      // If no exercises found, create some demo exercises
      const demoExercises = [
        {
          id: 1000 + programId,
          name: "Warm-up Routine",
          description: "A series of dynamic exercises to warm up the body.",
          type: "preparation",
          difficulty: "beginner",
          instructions: "1. Jog in place for 2 minutes\n2. 20 jumping jacks\n3. 10 arm circles each direction\n4. 10 high knees each leg\n5. 5 body-weight squats",
          imageUrl: null,
          videoId: "HDfvWrGUkC8" // Beginner warm-up routine
        },
        {
          id: 2000 + programId,
          name: "Core Strength Circuit",
          description: "Build foundational strength with this circuit.",
          type: "strength",
          difficulty: "intermediate",
          instructions: "1. 15 push-ups (modified if needed)\n2. 30-second plank\n3. 15 bodyweight squats\n4. 10 mountain climbers per side\n5. 15 bicycle crunches per side\n\nRest 60 seconds between rounds. Complete 3 rounds.",
          imageUrl: null,
          videoId: "rM92ygzQwwA" // Core strength workout
        },
        {
          id: 3000 + programId,
          name: "Combat Technique Training",
          description: "Practice essential defensive and offensive techniques.",
          type: "combat",
          difficulty: "advanced",
          instructions: "1. Shadow boxing - 2 minutes\n2. Practice blocks against imaginary attacks - 2 minutes\n3. Stance and footwork drills - 3 minutes\n4. Basic striking combinations - 3 minutes\n5. Defensive maneuvers - 3 minutes\n\nFocus on proper form rather than speed.",
          imageUrl: null,
          videoId: "7q1rSlEUZJw" // Beginner to intermediate martial arts techniques
        }
      ];
      
      return res.json(demoExercises);
    }
    
    res.json(exercises);
  });
  
  // Youtube Video search endpoint
  apiRouter.get("/youtube/search", async (req, res) => {
    const { query } = req.query;
    
    if (!query) {
      return res.status(400).json({ message: "Search query is required" });
    }
    
    if (!process.env.YOUTUBE_API_KEY) {
      return res.status(500).json({ message: "YouTube API key not configured" });
    }
    
    try {
      const response = await fetch(
        `https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=1&q=${encodeURIComponent(
          query as string
        )}&type=video&key=${process.env.YOUTUBE_API_KEY}`
      );
      
      if (!response.ok) {
        throw new Error(`YouTube API error: ${response.statusText}`);
      }
      
      const data = await response.json();
      
      if (!data.items || data.items.length === 0) {
        return res.json({ videoId: null });
      }
      
      const videoId = data.items[0].id.videoId;
      res.json({ videoId });
    } catch (error) {
      console.error("YouTube API error:", error);
      res.status(500).json({ message: (error as Error).message });
    }
  });

  apiRouter.get("/user/programs", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const userPrograms = await storage.getUserPrograms(userId);
    res.json(userPrograms);
  });

  apiRouter.post("/user/programs", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const userProgramData = insertUserProgramSchema.parse({
        ...req.body,
        userId
      });
      
      const program = await storage.getProgramById(userProgramData.programId);
      
      if (!program) {
        return res.status(404).json({ message: "Program not found" });
      }
      
      const userProgram = await storage.assignProgramToUser(userProgramData);
      res.status(201).json(userProgram);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  apiRouter.patch("/user/programs/:id/progress", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const userProgramId = parseInt(req.params.id);
    
    if (isNaN(userProgramId)) {
      return res.status(400).json({ message: "Invalid user program ID" });
    }
    
    try {
      const { progress, isCompleted } = z.object({
        progress: z.number().min(0).max(100),
        isCompleted: z.boolean().optional()
      }).parse(req.body);
      
      const updatedUserProgram = await storage.updateUserProgramProgress(
        userProgramId, 
        progress, 
        isCompleted
      );
      
      res.json(updatedUserProgram);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  // Achievements
  apiRouter.get("/achievements", async (req, res) => {
    const achievements = await storage.getAllAchievements();
    res.json(achievements);
  });

  apiRouter.get("/user/achievements", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const userAchievements = await storage.getUserAchievements(userId);
    res.json(userAchievements);
  });

  apiRouter.get("/user/achievements/recent", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const limit = parseInt(req.query.limit as string || "3");
    const recentAchievements = await storage.getRecentUserAchievements(userId, limit);
    res.json(recentAchievements);
  });

  // Mentorship
  apiRouter.get("/user/mentor", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const mentorship = await storage.getMentorshipByMenteeId(userId);
    
    if (!mentorship) {
      return res.status(404).json({ message: "No active mentorship found" });
    }
    
    const guidance = await storage.getLatestMentorGuidance(mentorship.id);
    
    res.json({
      mentor: {
        id: mentorship.mentor.id,
        username: mentorship.mentor.username,
        firstName: mentorship.mentor.firstName,
        lastName: mentorship.mentor.lastName,
        profileImage: mentorship.mentor.profileImage,
        level: mentorship.mentor.level,
        role: mentorship.mentor.role
      },
      mentorship: {
        id: mentorship.id,
        startedAt: mentorship.startedAt,
        status: mentorship.status
      },
      guidance
    });
  });

  apiRouter.post("/mentor/guidance", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const user = await storage.getUser(userId);
    
    if (!user || user.role !== "batman") {
      return res.status(403).json({ message: "Only mentors can add guidance" });
    }
    
    try {
      const guidanceData = insertMentorGuidanceSchema.parse(req.body);
      
      // Verify the mentor is part of this mentorship
      const mentorships = Array.from(await storage.getAllMentorships())
        .filter(m => m.id === guidanceData.mentorshipId && m.mentorId === userId);
      
      if (mentorships.length === 0) {
        return res.status(403).json({ message: "You are not the mentor for this mentorship" });
      }
      
      const guidance = await storage.createMentorGuidance(guidanceData);
      res.status(201).json(guidance);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  // Weekly Activity
  apiRouter.get("/user/activity", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const startDateStr = req.query.startDate as string;
      const endDateStr = req.query.endDate as string;
      
      if (!startDateStr || !endDateStr) {
        return res.status(400).json({ message: "Start and end dates are required" });
      }
      
      const startDate = new Date(startDateStr);
      const endDate = new Date(endDateStr);
      
      if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
        return res.status(400).json({ message: "Invalid date format" });
      }
      
      const activities = await storage.getWeeklyActivity(userId, startDate, endDate);
      res.json(activities);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  apiRouter.post("/user/activity", async (req, res) => {
    const userId = req.session.userId;
    
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const activityData = insertWeeklyActivitySchema.parse({
        ...req.body,
        userId
      });
      
      const activity = await storage.recordActivity(activityData);
      res.status(201).json(activity);
    } catch (error) {
      res.status(400).json({ message: (error as Error).message });
    }
  });

  // Helper for storage to get all mentorships (used in mentor guidance validation)
  storage.getAllMentorships = async function() {
    return Array.from(this.mentorships.values());
  };

  const httpServer = createServer(app);
  return httpServer;
}
