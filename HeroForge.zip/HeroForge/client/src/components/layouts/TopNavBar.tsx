import React from "react";
import { useQuery } from "@tanstack/react-query";
import { useMobileNav } from "@/hooks/use-mobile-nav";

const TopNavBar: React.FC = () => {
  const { setIsOpen } = useMobileNav();
  
  const { data: user } = useQuery({
    queryKey: ["/api/auth/me"],
    staleTime: Infinity,
  });

  return (
    <div className="bg-muted px-6 py-3 flex items-center justify-between lg:hidden">
      <div className="flex items-center">
        <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
          <span className="text-primary-foreground text-sm">🦇</span>
        </div>
        <h1 className="ml-2 text-lg font-bold tracking-wider">
          BAT<span className="text-primary">TRAIN</span>
        </h1>
      </div>
      <button 
        className="text-foreground focus:outline-none"
        onClick={() => setIsOpen(true)}
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="h-6 w-6"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M4 6h16M4 12h16M4 18h16"
          />
        </svg>
      </button>
    </div>
  );
};

export default TopNavBar;
