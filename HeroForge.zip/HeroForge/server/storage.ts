import {
  users, type User, type InsertUser,
  programs, type Program, type InsertProgram,
  exercises, type Exercise, type InsertExercise,
  programExercises, type ProgramExercise, type InsertProgramExercise,
  userPrograms, type UserProgram, type InsertUserProgram,
  achievements, type Achievement, type InsertAchievement,
  userAchievements, type UserAchievement, type InsertUserAchievement,
  mentorships, type Mentorship, type InsertMentorship,
  mentorGuidance, type MentorGuidance, type InsertMentorGuidance,
  weeklyActivity, type WeeklyActivity, type InsertWeeklyActivity
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserLevel(id: number, level: number, experience: number): Promise<User>;
  
  // Program methods
  createProgram(program: InsertProgram): Promise<Program>;
  getAllPrograms(): Promise<Program[]>;
  getProgramById(id: number): Promise<Program | undefined>;
  getProgramsByMentorId(mentorId: number): Promise<Program[]>;
  
  // Exercise methods
  createExercise(exercise: InsertExercise): Promise<Exercise>;
  getAllExercises(): Promise<Exercise[]>;
  
  // Program Exercise methods
  addExerciseToProgram(programExercise: InsertProgramExercise): Promise<ProgramExercise>;
  getExercisesByProgramId(programId: number): Promise<Exercise[]>;
  
  // User Program methods
  assignProgramToUser(userProgram: InsertUserProgram): Promise<UserProgram>;
  getUserPrograms(userId: number): Promise<(UserProgram & { program: Program })[]>;
  updateUserProgramProgress(id: number, progress: number, isCompleted?: boolean): Promise<UserProgram>;
  
  // Achievement methods
  createAchievement(achievement: InsertAchievement): Promise<Achievement>;
  getAllAchievements(): Promise<Achievement[]>;
  getAchievementById(id: number): Promise<Achievement | undefined>;
  
  // User Achievement methods
  awardAchievementToUser(userAchievement: InsertUserAchievement): Promise<UserAchievement>;
  getUserAchievements(userId: number): Promise<(UserAchievement & { achievement: Achievement })[]>;
  getRecentUserAchievements(userId: number, limit: number): Promise<(UserAchievement & { achievement: Achievement })[]>;
  
  // Mentorship methods
  createMentorship(mentorship: InsertMentorship): Promise<Mentorship>;
  getMentorshipByMenteeId(menteeId: number): Promise<(Mentorship & { mentor: User }) | undefined>;
  
  // Mentor Guidance methods
  createMentorGuidance(guidance: InsertMentorGuidance): Promise<MentorGuidance>;
  getLatestMentorGuidance(mentorshipId: number): Promise<MentorGuidance | undefined>;
  
  // Weekly Activity methods
  recordActivity(activity: InsertWeeklyActivity): Promise<WeeklyActivity>;
  getWeeklyActivity(userId: number, startDate: Date, endDate: Date): Promise<WeeklyActivity[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private programs: Map<number, Program>;
  private exercises: Map<number, Exercise>;
  private programExercises: Map<number, ProgramExercise>;
  private userPrograms: Map<number, UserProgram>;
  private achievements: Map<number, Achievement>;
  private userAchievements: Map<number, UserAchievement>;
  private mentorships: Map<number, Mentorship>;
  private mentorGuidance: Map<number, MentorGuidance>;
  private weeklyActivities: Map<number, WeeklyActivity>;

  private userIdCounter: number;
  private programIdCounter: number;
  private exerciseIdCounter: number;
  private programExerciseIdCounter: number;
  private userProgramIdCounter: number;
  private achievementIdCounter: number;
  private userAchievementIdCounter: number;
  private mentorshipIdCounter: number;
  private mentorGuidanceIdCounter: number;
  private weeklyActivityIdCounter: number;

  constructor() {
    this.users = new Map();
    this.programs = new Map();
    this.exercises = new Map();
    this.programExercises = new Map();
    this.userPrograms = new Map();
    this.achievements = new Map();
    this.userAchievements = new Map();
    this.mentorships = new Map();
    this.mentorGuidance = new Map();
    this.weeklyActivities = new Map();

    this.userIdCounter = 1;
    this.programIdCounter = 1;
    this.exerciseIdCounter = 1;
    this.programExerciseIdCounter = 1;
    this.userProgramIdCounter = 1;
    this.achievementIdCounter = 1;
    this.userAchievementIdCounter = 1;
    this.mentorshipIdCounter = 1;
    this.mentorGuidanceIdCounter = 1;
    this.weeklyActivityIdCounter = 1;
    
    // Initialize with sample data
    this.initializeData();
  }

  private initializeData(): void {
    // Create batman user (mentor)
    const batman: InsertUser = {
      username: "batman",
      password: "password",
      firstName: "Bruce",
      lastName: "Wayne",
      email: "bruce@wayne.com",
      profileImage: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5"
    };
    
    const batmanUser = this.createUser(batman);
    
    // Update batman to be a mentor with max level
    this.users.set(batmanUser.id, {
      ...batmanUser,
      role: "batman",
      level: 10
    });
    
    // Create sample robin user
    const robin: InsertUser = {
      username: "robin",
      password: "password",
      firstName: "Dick",
      lastName: "Grayson",
      email: "dick@wayne.com",
      profileImage: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5"
    };
    
    const robinUser = this.createUser(robin);
    
    // Create mentorship
    this.createMentorship({
      mentorId: batmanUser.id,
      menteeId: robinUser.id,
      status: "active"
    });
    
    // Create achievements
    const combatBasicsAchievement = this.createAchievement({
      name: "Combat Basics",
      description: "Completed 5 basic combat sessions",
      iconName: "fist-raised",
      category: "combat",
      requiredLevel: 1
    });
    
    const agilityMasterAchievement = this.createAchievement({
      name: "Agility Master",
      description: "Completed all agility exercises",
      iconName: "running",
      category: "agility",
      requiredLevel: 2
    });
    
    const detectiveSkillsAchievement = this.createAchievement({
      name: "Detective Skills",
      description: "Solved 3 training cases",
      iconName: "brain",
      category: "intelligence",
      requiredLevel: 3
    });
    
    // Award achievements to robin
    this.awardAchievementToUser({
      userId: robinUser.id,
      achievementId: combatBasicsAchievement.id
    });
    
    this.awardAchievementToUser({
      userId: robinUser.id,
      achievementId: agilityMasterAchievement.id
    });
    
    this.awardAchievementToUser({
      userId: robinUser.id,
      achievementId: detectiveSkillsAchievement.id
    });
    
    // Create training programs
    const combatProgram = this.createProgram({
      title: "Combat Training",
      description: "Basic fighting techniques and self-defense",
      imageUrl: "https://images.unsplash.com/photo-1549060279-7e168fcee0c2",
      duration: "8 weeks",
      difficulty: "intermediate",
      createdById: batmanUser.id
    });
    
    const stealthProgram = this.createProgram({
      title: "Stealth & Agility",
      description: "Move silently and improve reaction time",
      imageUrl: "https://images.unsplash.com/photo-1599058917212-d750089bc07e",
      duration: "6 weeks",
      difficulty: "beginner",
      createdById: batmanUser.id
    });
    
    // Assign programs to robin
    this.assignProgramToUser({
      userId: robinUser.id,
      programId: combatProgram.id,
      progress: 75,
      isCompleted: false
    });
    
    this.assignProgramToUser({
      userId: robinUser.id,
      programId: stealthProgram.id,
      progress: 10,
      isCompleted: false
    });
    
    // Add mentor guidance
    const mentorship = this.getMentorshipByMenteeId(robinUser.id);
    if (mentorship) {
      this.createMentorGuidance({
        mentorshipId: mentorship.id,
        message: "Remember, it's not just about physical strength, but mental discipline. Focus on your technique this week.",
        focus: "Combat stance and basic strikes",
        priority: "high"
      });
    }
    
    // Add weekly activity data for Robin
    const now = new Date();
    const daysOfWeek = 7;
    const activities = [30, 60, 40, 85, 65, 20, 50]; // percentages of daily activity
    
    for (let i = 0; i < daysOfWeek; i++) {
      const date = new Date(now);
      date.setDate(date.getDate() - (daysOfWeek - 1) + i);
      
      this.recordActivity({
        userId: robinUser.id,
        date,
        minutes: Math.floor(activities[i] * 1.2), // Convert percentage to minutes (arbitrary formula)
        intensity: i === 3 ? "high" : "medium", // Thursday (index 3) is high intensity
        programId: i % 2 === 0 ? combatProgram.id : stealthProgram.id
      });
    }
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const newUser: User = { 
      ...user, 
      id, 
      level: 1, 
      experience: 0,
      role: "robin"
    };
    this.users.set(id, newUser);
    return newUser;
  }
  
  async updateUserLevel(id: number, level: number, experience: number): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error(`User with id ${id} not found`);
    }
    
    const updatedUser = { ...user, level, experience };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Program methods
  async createProgram(program: InsertProgram): Promise<Program> {
    const id = this.programIdCounter++;
    const newProgram: Program = { ...program, id };
    this.programs.set(id, newProgram);
    return newProgram;
  }

  async getAllPrograms(): Promise<Program[]> {
    return Array.from(this.programs.values());
  }

  async getProgramById(id: number): Promise<Program | undefined> {
    return this.programs.get(id);
  }

  async getProgramsByMentorId(mentorId: number): Promise<Program[]> {
    return Array.from(this.programs.values()).filter(
      (program) => program.createdById === mentorId
    );
  }

  // Exercise methods
  async createExercise(exercise: InsertExercise): Promise<Exercise> {
    const id = this.exerciseIdCounter++;
    const newExercise: Exercise = { ...exercise, id };
    this.exercises.set(id, newExercise);
    return newExercise;
  }

  async getAllExercises(): Promise<Exercise[]> {
    return Array.from(this.exercises.values());
  }

  // Program Exercise methods
  async addExerciseToProgram(programExercise: InsertProgramExercise): Promise<ProgramExercise> {
    const id = this.programExerciseIdCounter++;
    const newProgramExercise: ProgramExercise = { ...programExercise, id };
    this.programExercises.set(id, newProgramExercise);
    return newProgramExercise;
  }

  async getExercisesByProgramId(programId: number): Promise<Exercise[]> {
    const programExerciseEntries = Array.from(this.programExercises.values())
      .filter((pe) => pe.programId === programId)
      .sort((a, b) => a.order - b.order);

    return programExerciseEntries
      .map((pe) => this.exercises.get(pe.exerciseId))
      .filter((e): e is Exercise => e !== undefined);
  }

  // User Program methods
  async assignProgramToUser(userProgram: InsertUserProgram): Promise<UserProgram> {
    const id = this.userProgramIdCounter++;
    const now = new Date();
    const newUserProgram: UserProgram = { 
      ...userProgram, 
      id, 
      startedAt: now,
      completedAt: null
    };
    this.userPrograms.set(id, newUserProgram);
    return newUserProgram;
  }

  async getUserPrograms(userId: number): Promise<(UserProgram & { program: Program })[]> {
    const userPrograms = Array.from(this.userPrograms.values()).filter(
      (up) => up.userId === userId
    );

    return userPrograms.map((up) => {
      const program = this.programs.get(up.programId);
      if (!program) {
        throw new Error(`Program with id ${up.programId} not found`);
      }
      return { ...up, program };
    });
  }

  async updateUserProgramProgress(id: number, progress: number, isCompleted: boolean = false): Promise<UserProgram> {
    const userProgram = this.userPrograms.get(id);
    if (!userProgram) {
      throw new Error(`UserProgram with id ${id} not found`);
    }

    const updatedUserProgram: UserProgram = { 
      ...userProgram, 
      progress, 
      isCompleted,
      completedAt: isCompleted ? new Date() : null
    };
    
    this.userPrograms.set(id, updatedUserProgram);
    return updatedUserProgram;
  }

  // Achievement methods
  async createAchievement(achievement: InsertAchievement): Promise<Achievement> {
    const id = this.achievementIdCounter++;
    const newAchievement: Achievement = { ...achievement, id };
    this.achievements.set(id, newAchievement);
    return newAchievement;
  }

  async getAllAchievements(): Promise<Achievement[]> {
    return Array.from(this.achievements.values());
  }

  async getAchievementById(id: number): Promise<Achievement | undefined> {
    return this.achievements.get(id);
  }

  // User Achievement methods
  async awardAchievementToUser(userAchievement: InsertUserAchievement): Promise<UserAchievement> {
    const id = this.userAchievementIdCounter++;
    const now = new Date();
    const newUserAchievement: UserAchievement = { 
      ...userAchievement, 
      id, 
      earnedAt: now 
    };
    this.userAchievements.set(id, newUserAchievement);
    return newUserAchievement;
  }

  async getUserAchievements(userId: number): Promise<(UserAchievement & { achievement: Achievement })[]> {
    const userAchievements = Array.from(this.userAchievements.values()).filter(
      (ua) => ua.userId === userId
    );

    return userAchievements.map((ua) => {
      const achievement = this.achievements.get(ua.achievementId);
      if (!achievement) {
        throw new Error(`Achievement with id ${ua.achievementId} not found`);
      }
      return { ...ua, achievement };
    });
  }

  async getRecentUserAchievements(userId: number, limit: number): Promise<(UserAchievement & { achievement: Achievement })[]> {
    const userAchievements = await this.getUserAchievements(userId);
    return userAchievements
      .sort((a, b) => b.earnedAt.getTime() - a.earnedAt.getTime())
      .slice(0, limit);
  }

  // Mentorship methods
  async createMentorship(mentorship: InsertMentorship): Promise<Mentorship> {
    const id = this.mentorshipIdCounter++;
    const now = new Date();
    const newMentorship: Mentorship = { 
      ...mentorship, 
      id, 
      startedAt: now
    };
    this.mentorships.set(id, newMentorship);
    return newMentorship;
  }

  async getMentorshipByMenteeId(menteeId: number): Promise<(Mentorship & { mentor: User }) | undefined> {
    const mentorship = Array.from(this.mentorships.values()).find(
      (m) => m.menteeId === menteeId && m.status === "active"
    );

    if (!mentorship) {
      return undefined;
    }

    const mentor = this.users.get(mentorship.mentorId);
    if (!mentor) {
      throw new Error(`Mentor with id ${mentorship.mentorId} not found`);
    }

    return { ...mentorship, mentor };
  }

  // Mentor Guidance methods
  async createMentorGuidance(guidance: InsertMentorGuidance): Promise<MentorGuidance> {
    const id = this.mentorGuidanceIdCounter++;
    const now = new Date();
    const newGuidance: MentorGuidance = { 
      ...guidance, 
      id, 
      createdAt: now 
    };
    this.mentorGuidance.set(id, newGuidance);
    return newGuidance;
  }

  async getLatestMentorGuidance(mentorshipId: number): Promise<MentorGuidance | undefined> {
    const guidances = Array.from(this.mentorGuidance.values())
      .filter((g) => g.mentorshipId === mentorshipId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());

    return guidances[0];
  }

  // Weekly Activity methods
  async recordActivity(activity: InsertWeeklyActivity): Promise<WeeklyActivity> {
    const id = this.weeklyActivityIdCounter++;
    const newActivity: WeeklyActivity = { ...activity, id };
    this.weeklyActivities.set(id, newActivity);
    return newActivity;
  }

  async getWeeklyActivity(userId: number, startDate: Date, endDate: Date): Promise<WeeklyActivity[]> {
    return Array.from(this.weeklyActivities.values())
      .filter(
        (a) => a.userId === userId && 
               a.date >= startDate && 
               a.date <= endDate
      )
      .sort((a, b) => a.date.getTime() - b.date.getTime());
  }
}

// Import the DatabaseStorage class (moved to top of file)
// export const storage = new MemStorage();

// Use DatabaseStorage instead of MemStorage
import { DatabaseStorage } from "./dbStorage";
export const storage = new DatabaseStorage();
